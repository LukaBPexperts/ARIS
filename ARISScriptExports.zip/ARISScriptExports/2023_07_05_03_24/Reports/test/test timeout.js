var a=2

Dialogs.MsgBox("You selected")


Dialogs.MsgBox("2")


