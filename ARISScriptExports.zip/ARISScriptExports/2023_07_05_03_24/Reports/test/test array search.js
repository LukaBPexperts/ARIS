var arrayGUIDs = ['guid1', 'guid2', 'guid3'];

var index = arrayGUIDs.indexOf('guid2');


var a=2