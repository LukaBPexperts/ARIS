Dialogs.MsgBox("Visio import not available");

// /***************************************************
 // * Copyright (c) Software AG. All Rights Reserved. *
 // ***************************************************/
