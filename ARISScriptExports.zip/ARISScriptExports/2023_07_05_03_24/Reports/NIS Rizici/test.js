var a=0
var guidTemp = "a" //get GUID from excell       
var guidNext = "a"


var selectedDb = ArisData.getSelectedDatabases()

var riskDef = selectedDb[0].FindGUID("")



for(var i=0; i<10; i++){
    var a=3
        
        do{
           var  a = a+1
            
        }while(guidTemp == guidNext)
        
        
        var b =3
        
}