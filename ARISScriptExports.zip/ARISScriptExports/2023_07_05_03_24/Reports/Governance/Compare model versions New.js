/**
 * Copyright (C) 2019 Software AG, Darmstadt, Germany and/or Software AG USA Inc., Reston, VA, USA,
 * and/or its subsidiaries and/or its affiliates and/or their licensors.
 *
 * Use, reproduction, transfer, publication or disclosure is prohibited
 * except as specifically provided for in your License Agreement with Software AG.
 *
 * Version: 10.0.11.0.1400208
 */

// BLUE-17650 - Import/Usage of 'convertertools.js' removed 

Context.setProperty("excel-formulas-allowed", false); //default value is provided by server setting (tenant-specific): "abs.report.excel-formulas-allowed"
 
 // Globals-----------------------------------------------------------------------------------------
    var gn_Lang         = Context.getSelectedLanguage();
    var gs_Filter       = ArisData.ActiveFilter().GUID();
    var gn_Format   	= Context.getSelectedFormat();
    var gs_Section      = "SCRIPT_13556fe0-59d4-11e0-785f-996f2eafddb7";
    var gs_Empty    	= new java.lang.String("");
    var ga_Context      = [getString("TEXT_WORKSPACE"), getString("TEXT_CURRVERSION"), getString("TEXT_CHNGLIST")];
    var gn_errLogin     = 100;// Bad user Login name or Password; problems login into DB
    var gn_errNoCmp     = 110;// No suitable models found according user settings criteria
    var gn_errNoDB      = 101;// Desired version DB not retrieved
    var gn_ModelCount   = -1;// Number of comparison models/ array entries of aElement
    var ga_Conditions   = new Array();
    var ga_Summary      = new Array();
    var ga_ModelGraphic = new Array();
    var isVersionable 	= true;
	var gs_FileName 	= "Model_comparison.xls";

    // BLUE-4104 In case of cross-database comparison uses same filter and language and compares with workspace (so dialog 100 seems not really necessary)    
    var gb_showDlg100  = false;          

    // DEFINE Global Color Style-----------------------------------------------------------------------
    var CC_BLACK        = Constants.C_BLACK;
    var CC_WHITE        = Constants.C_WHITE;
    var CC_TRANSPARENT  = Constants.C_TRANSPARENT;
    var CC_DARK_GREEN   = RGB(0, 128, 128);
    var CC_BLUE         = Constants.C_BLUE;
    var CC_RED          = Constants.C_RED;
    var CC_YELLOW       = Constants.C_YELLOW;
    var CC_GREEN        = Constants.C_GREEN;
    
    // DO NOT TRANSLATE !!!----------------------------------------------------------------------------
    var c_xmlCondition  = "condition";      // condition
    var c_xmlAction     = "action";         // action
    var c_xmlSymbolType = "symbol-type";    // symbol-type    
    var c_xmlCxnType    = "cxn-type";       // cxn-type
    var c_xmlAttrType   = "attr-type";      // attr-type
    var c_xmlType       = "type";           // type
    var c_xmlMsgText    = "msg-text";       // msg-text
    var gs_Updated      = "UPDATED";        // UPDATED
    var gs_Created      = "CREATED";        // CREATED
    var gs_Deleted      = "DELETED";        // DELETED
    
    // Default texts for summary-----------------------------------------------------------------------    
    var c_sDefaultText_SomethingCreated = getString("DEFAULTTEXT_SOMETHING_CREATED");
    var c_sDefaultText_SomethingUpdated = getString("DEFAULTTEXT_SOMETHING_UPDATED");
    var c_sDefaultText_SomethingDeleted = getString("DEFAULTTEXT_SOMETHING_DELETED");
    
    
    var c_sDefaultText_SymbolTypeCreated = getString("DEFAULTTEXT_SYMBOLTYPE_CREATED");
    var c_sDefaultText_SymbolTypeUpdated = getString("DEFAULTTEXT_SYMBOLTYPE_UPDATED");
    var c_sDefaultText_SymbolTypeDeleted = getString("DEFAULTTEXT_SYMBOLTYPE_DELETED");
    
    var c_sDefaultText_CxnTypeCreated = getString("DEFAULTTEXT_CXNTYPE_CREATED");
    var c_sDefaultText_CxnTypeUpdated = getString("DEFAULTTEXT_CXNTYPE_UPDATED");
    var c_sDefaultText_CxnTypeDeleted = getString("DEFAULTTEXT_CXNTYPE_DELETED");
    
    var c_sDefaultText_AttrTypeCreated = getString("DEFAULTTEXT_ATTRTYPE_CREATED");
    var c_sDefaultText_AttrTypeUpdated = getString("DEFAULTTEXT_ATTRTYPE_UPDATED");
    var c_sDefaultText_AttrTypeDeleted = getString("DEFAULTTEXT_ATTRTYPE_DELETED");
    
    var c_sDefaultText_CxnType_AttrTypeCreated = getString("DEFAULTTEXT_CXNTYPE_ATTRTYPE_CREATED");
    var c_sDefaultText_CxnType_AttrTypeUpdated = getString("DEFAULTTEXT_CXNTYPE_ATTRTYPE_UPDATED");
    var c_sDefaultText_CxnType_AttrTypeDeleted = getString("DEFAULTTEXT_CXNTYPE_ATTRTYPE_DELETED");
    // Comparision classes-----------------------------------------------------------------------------
    __cmp_Statistics        = function( ){
        this.CmpExistFirstMod       = 0;
        this.CmpExistSecondMod      = 0;
        this.CmpChangeBothMod       = 0;
        this.ItmModProperties       = 0;

        this.ItmObjDefinitions      = new Array();
            this.ItmObjAttributes   = 0;
            this.ItmObjOccurrences  = new Array();
            this.ItmObjAppearance   = 0;
            this.ItmObjPosition     = 0;
            this.ItmObjAttrPlace    = 0;
            
        this.ItmCxnDefinitions      = new Array();
            this.ItmCxnAttributes   = 0;
            this.ItmCxnOccurrences  = new Array();
            this.ItmCxnAppearance   = 0;
            this.ItmCxnPosition     = 0;
            this.ItmCxnAttrPlace    = 0;

        this.ItmGraphicObjects      = 0;
        this.ItmOLEObjects          = 0;
        this.ItmFreeText            = 0;

        __cmp_Statistics.prototype.Set	= function( oDifference ){
			switch( oDifference.getDifferenceType() ){// Get Existence OR Difference
                case Constants.MODCOMP_DIFF_LEFTONLY:// Existence
                    this.CmpExistFirstMod++;
                    break;
                case Constants.MODCOMP_DIFF_RIGHTONLY:// Existence
                    this.CmpExistSecondMod++;
                    break;
                case Constants.MODCOMP_DIFF_BOTH:// Difference
                    this.CmpChangeBothMod++;
                    break;
            }

            switch( oDifference.getExistingElement().KindNum() ){
                case Constants.CID_MODEL:
                    this.ItmModProperties++;
                    break;
                case Constants.CID_OBJDEF:
                case Constants.CID_OBJOCC:
                    if( oDifference.getDifferenceSubType() == Constants.MODCOMP_DEFINITION) {
                        var oObjDef = (oDifference.getExistingElement().KindNum() == Constants.CID_OBJDEF) ? oDifference.getExistingElement() : oDifference.getExistingElement().ObjDef();
                        this.ItmObjDefinitions.push(oObjDef);
                    }
                    if( oDifference.getDifferenceSubType() == Constants.MODCOMP_OCCURENCE) {
                        if (oDifference.getExistingElement().KindNum() == Constants.CID_OBJOCC) {
                            this.ItmObjOccurrences.push(oDifference.getExistingElement());
                        }
                    }
                    if( oDifference.isSubElementChanged() == true ){// Get Difference in attribute...
                        if( oDifference.getDifferenceSubType() == Constants.MODCOMP_ATTRIBUTE_OCC && 
                            (oDifference.getDifferenceKind() == Constants.MODCOMP_DIFFKIND_ATTR_PLACEMENT || oDifference.getDifferenceKind() == Constants.MODCOMP_DIFFKIND_ATTR_PORT) ) {
                            this.ItmObjAttrPlace++;
                        }
                        if( oDifference.getDifferenceSubType() == Constants.MODCOMP_ATTRIBUTE_DEF ) {
                            this.ItmObjAttributes++;
                        }
                    }
                    if( oDifference.isSubElementChanged() == false ){// Get Difference in existence, appearance, size, position,...
                        switch( oDifference.getDifferenceKind() ){
                            case Constants.MODCOMP_DIFFKIND_POSITION:
                            case Constants.MODCOMP_DIFFKIND_SIZE:
                                this.ItmObjPosition++;
                                break;
                            case Constants.MODCOMP_DIFFKIND_APPEARENCE:
                            case Constants.MODCOMP_DIFFKIND_SYMBOL:
                                this.ItmObjAppearance++;
                                break;
                        }
                    }
                    break;
                case Constants.CID_CXNDEF:
                case Constants.CID_CXNOCC:
                    if( oDifference.getDifferenceSubType() == Constants.MODCOMP_DEFINITION) {
                        var oCxnDef = (oDifference.getExistingElement().KindNum() == Constants.CID_CXNDEF) ? oDifference.getExistingElement() : oDifference.getExistingElement().CxnDef();
                        this.ItmCxnDefinitions.push(oCxnDef);
                    }
                    if( oDifference.getDifferenceSubType() == Constants.MODCOMP_OCCURENCE) {
                        if (oDifference.getExistingElement().KindNum() == Constants.CID_CXNOCC) {
                            this.ItmCxnOccurrences.push(oDifference.getExistingElement());
                        }
                    }
                    if( oDifference.isSubElementChanged() == true ){// Get Difference in attribute...
                        if( oDifference.getDifferenceSubType() == Constants.MODCOMP_ATTRIBUTE_OCC && 
                            (oDifference.getDifferenceKind() == Constants.MODCOMP_DIFFKIND_ATTR_PLACEMENT || oDifference.getDifferenceKind() == Constants.MODCOMP_DIFFKIND_ATTR_PORT) ) { this.ItmCxnAttrPlace++; }
                        if( oDifference.getDifferenceSubType() == Constants.MODCOMP_ATTRIBUTE_DEF ) { this.ItmCxnAttributes++; }
                    }
                    if( oDifference.isSubElementChanged() == false ){// Get Difference in existence, appearance, size, position,...
                        switch( oDifference.getDifferenceKind() ){
                            case Constants.MODCOMP_DIFFKIND_CXNPOINTS:
                            case Constants.MODCOMP_DIFFKIND_POINTS:
                                this.ItmCxnPosition++;
                                break;
                            case Constants.MODCOMP_DIFFKIND_CXN_APPEARENCE:
                            case Constants.MODCOMP_DIFFKIND_APPEARENCE:
                            case Constants.MODCOMP_DIFFKIND_SYMBOL:
                                this.ItmCxnAppearance++;
                                break;
                        }
                    }
                    break;
                case Constants.CID_COMOBJDEF:
                case Constants.CID_COMOBJOCC:
                    this.ItmOLEObjects++;
                    break;
                case Constants.CID_TEXTDEF:
                case Constants.CID_TEXTOCC:
                    this.ItmFreeText++;
                    break;
                case Constants.CID_GFXOBJ:
                    this.ItmGraphicObjects++;
                    break;
            }// END::switch_KindNum
		}
    }
    
    __cmp_Occurrences       = function( ){
        this.Checked        = true;
        this.Appearance     = false;
        this.Position       = false;
        this.AttrPlace      = false;
    }

    __cmp_Definitions       = function( ){
        this.Checked        = true;
        this.Attributes     = true;
            this.SystemAttributes   = false;
        this.Occurrences    = new __cmp_Occurrences();
    }
    
    __cmp_ComparisonOptions         = function( ){
        this.CmpExistFirstMod       = true;
        this.CmpExistSecondMod      = true;
        this.CmpChangeBothMod       = true;
    
        this.ItmModProperties       = true;
        this.ItmObjDefinitions      = new __cmp_Definitions( );
        this.ItmCxnDefinitions      = new __cmp_Definitions( );
        this.ItmGraphicObjects      = true;
        this.ItmOLEObjects          = true;
        this.ItmFreeText            = true;
        
        this.AddIdenticalAttr       = false;
        this.AddAttrNumber          = Constants.AT_NAME;
        this.AddMatchCase           = false;
        this.AddLineBreaksSpaces    = false;
        
        this.MasterVariantComp      = false
    }

    __usertype_tComparisonSet   = function( ){
        this.aModels            = ArisData.getSelectedModels( getModelTypesIncludingUserDefined_Array( Context.getDefinedItemTypes(Constants.CID_MODEL) ) );
        this.oRefModel          = ( (this.aModels != null) && (this.aModels.length == 1) )?this.aModels[0]:null;
        this.oActDB             = ArisData.getActiveDatabase( );        

        this.nDBCompare         = 0;
        this.nModCompare        = 0;

        this.aCompModels        = null;
        this.oCompDB            = null;
        this.oCmpOptions        = null;// new __cmp_ComparisonOptions( );
        this.oCmpStatistics     = null;// new __cmp_Statistics( );
        
        if( (this.aModels != null) && (this.aModels.length > 1) ){
            this.aModels.sort( sortLangNames );
        }

        __usertype_tComparisonSet.prototype.getScope    = function( oUsrSettings ){
            var aTmp            = new Array();
            this.oRefModel      = oUsrSettings.RefModel;// Reference model
            this.aCompModels    = oUsrSettings.CompModels;//.copy();// Array of selected models for comparision
                aTmp.push(this.oRefModel);
            this.aModels        = aTmp.concat( this.aCompModels );// Merged Reference model (index==0) with comparision models (index > 0)

            this.nDBCompare     = oUsrSettings.P11DBCompare;// Option for comparison of models: 0->Within One DB, 1->Cross DB comparision
            this.nModCompare    = oUsrSettings.P11ModCompare;// Option for comparison of models: 0->Versions, 1->Masters/variants, 2->Attribute, 3->GUID, 4->Selected models

            this.oCompDB        = oUsrSettings.CompDB;// Cross compare DB opened using P10Login, P10Password, P100Filter, P100Lang, as read-only
            this.oCmpOptions    = oUsrSettings.oCmpOptions;// User set Comparision Options
            this.oCmpStatistics = new __cmp_Statistics( );

            gn_ModelCount       = this.aCompModels.length;
        }//END::getScope()

        __usertype_tComparisonSet.prototype.outputStatistics    = function( p_Output, sCriterion, sText ){
            if( (p_Output != null) && ( sCriterion != null) && (sText != null) ){
                var nResult     = "";
                var sSetting    = "";
                
                if( sCriterion == "Criterion" ){
                    var sTmp    = new Array();
                        sTmp.push( ((this.nDBCompare == 0)?getString("TEXT_WITHINDB"):getString("TEXT_CROSSDB")) );
                        if( this.nModCompare == 0 ) sTmp.push( getString("TEXT_CRITERION1") );
                        if( this.nModCompare == 1 ) sTmp.push( getString("TEXT_CRITERION2") );
                        if( this.nModCompare == 2 ) sTmp.push( getString("TEXT_CRITERION3") );
                        if( this.nModCompare == 3 ) sTmp.push( getString("TEXT_CRITERION4") );
                        if( this.nModCompare == 4 ) sTmp.push( getString("TEXT_CRITERION5") );
                    sSetting    = formatstring2( "@0,\n@1", sTmp );//commonUtils.attsall.
                } else if( sCriterion == "AddIdenticalAttr"){
                        if( this.oCmpOptions.AddIdenticalAttr == true){
                            sSetting    = formatstring1( getString("TEXT_MATCH_OUTPUT"), ArisData.ActiveFilter().AttrTypeName( this.oCmpOptions.AddAttrNumber ));
                            if( this.oCmpOptions.AddMatchCase == true )         sSetting = formatstring2("@1,\n@2", sSetting, getString("TEXT_MATCH1"));
                            if( this.oCmpOptions.AddLineBreaksSpaces == true )  sSetting = formatstring2("@1,\n@2", sSetting, getString("TEXT_MATCH2"));
                        } else{
                            sSetting    = getString("TEXT_MATCH_STANDARD");
                        }
                } else if(  (sCriterion == "CmpExistFirstMod") || (sCriterion == "CmpExistSecondMod") ||
                            (sCriterion == "CmpChangeBothMod") || (sCriterion == "ItmModProperties") ||
                            (sCriterion == "ItmGraphicObjects") || (sCriterion == "ItmOLEObjects") ||
                            (sCriterion == "ItmFreeText") ){
                        nResult     = eval( "this.oCmpStatistics." + sCriterion);
                        sSetting    = eval( "this.oCmpOptions." + sCriterion);
                        sSetting    = (sSetting == true)?getString("TEXT_OPTION_YES"):getString("TEXT_OPTION_NO");
                } else{
                    if( sCriterion == "ItmObjDefinitions" ) { sSetting = this.oCmpOptions.ItmObjDefinitions.Checked; }
                    if( sCriterion == "ItmObjAttributes" ) { sSetting = this.oCmpOptions.ItmObjDefinitions.Attributes; }
                    if( sCriterion == "ItmObjOccurrences" )  { sSetting = this.oCmpOptions.ItmObjDefinitions.Occurrences.Checked; }
                    if( sCriterion == "ItmObjAppearance" ) { sSetting = this.oCmpOptions.ItmObjDefinitions.Occurrences.Appearance; }
                    if( sCriterion == "ItmObjPosition") { sSetting = this.oCmpOptions.ItmObjDefinitions.Occurrences.Position; }
                    if( sCriterion == "ItmObjAttrPlace" ) { sSetting = this.oCmpOptions.ItmObjDefinitions.Occurrences.AttrPlace; }
                    if( sCriterion == "ItmCxnDefinitions" ) { sSetting = this.oCmpOptions.ItmCxnDefinitions.Checked; }
                    if( sCriterion == "ItmCxnAttributes" ) { sSetting = this.oCmpOptions.ItmCxnDefinitions.Attributes; }
                    if( sCriterion == "ItmCxnOccurrences" )  { sSetting = this.oCmpOptions.ItmCxnDefinitions.Occurrences.Checked; }
                    if( sCriterion == "ItmCxnAppearance" ) { sSetting = this.oCmpOptions.ItmCxnDefinitions.Occurrences.Appearance; }
                    if( sCriterion == "ItmCxnPosition" ) { sSetting = this.oCmpOptions.ItmCxnDefinitions.Occurrences.Position; }
                    if( sCriterion == "ItmCxnAttrPlace" ) { sSetting = this.oCmpOptions.ItmCxnDefinitions.Occurrences.AttrPlace; }
                    
                    nResult     = getResult(eval( "this.oCmpStatistics." + sCriterion), sCriterion );
                    sSetting    = (sSetting == true)?getString("TEXT_OPTION_YES"):getString("TEXT_OPTION_NO");
                }
                
                p_Output.TableRow( );// Comparison Criterion
                    addCell( p_Output, [1,1,1,1], sText, 35, "TEXT_STYLE_BOLD" );
                    addCell( p_Output, [1,1,1,1], sSetting, 20, "TEXT_STYLE_DEFAULT" );
                    addCell( p_Output, [1,1,1,1], nResult, 20, "TEXT_STYLE_DEFAULT" );
                    addCell( p_Output, [0,0,0,0], "", 25, "TEXT_STYLE_TRANSPARENT" );
            }
        }//END::outputStatistics()
        
        function getResult(result, sCriterion) {
            if( sCriterion == "ItmObjDefinitions" ||
                sCriterion == "ItmObjOccurrences" ||
                sCriterion == "ItmCxnDefinitions" || 
                sCriterion == "ItmCxnOccurrences" )  {
                // result is an array
                result = ArisData.Unique(result);
                return result.length;
                
            } else {
                // result is a number
                return result;
            }
        }
        
    }//END::__usertype_tComparisonSet()
    
    __cl_SubElement		= function( oObj, oSubObj, sName, bSubChange, nDiffType, nDiffKind, pDiffDetails, pValue ){
		this.oObj			= oObj;
        this.oSubObj    	= oSubObj;
		this.sName			= sName;
		this.bSubChange	    = false;
		this.nDiffType		= nDiffType;
        this.nDiffKind		= nDiffKind;
		this.sDiffDetails	= pDiffDetails;
        this.sValue			= pValue;
    }//END::__cl_SubElement
    
    __cl_MainElement		= function( oRefObj, sName, bSubChange, nType, nDiffType, nDiffKind, pDiffDetails, aElements ){
        this.oRefObj		= oRefObj;
		this.sName			= sName;
		this.bSubChange	    = false;
		this.nType			= nType;
		this.nDiffType		= nDiffType;
        this.nDiffKind		= nDiffKind;
		this.sDiffDetails	= pDiffDetails;
        this.aElements		= aElements;// Array of objects of type __cl_SubElement (comparison right side elements)
    }
    
    __usertype_tMsgInput = function() {
        this.nsymboltype = -1;
        this.ncxntype = -1;
        this.nattrtype = -1;
        this.saction = "";
        this.omodel = null;
        this.omodeltocompare = null;
        this.oobjdef = null;
        this.oobjdeftocompare = null;
        this.oattr = null;
        this.oattrtocompare = null;
        this.ocxndef = null;
        this.ocxndeftocompare = null;
        this.otranscxn = null;
        this.otranscxntocompare = null;
    }    
    
    __usertype_tSummaryEntry = function(stext, slink, saction) {
        this.stext = stext;
        this.slink = slink;
        this.saction = saction;
    }

    __usertype_tConditions = function( nsymboltype, ncxntype, nattrtype, saction, smsgtext ){
        this.nsymboltype = nsymboltype;
        this.ncxntype = ncxntype;
        this.nattrtype = nattrtype;
        this.saction = saction;
        this.smsgtext = smsgtext;
    }

// END::Globals------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------


//-------------------------------------------------------------------------------------------------
// MAIN part---------------------------------------------------------------------------------------
    
    // Set output options
    Context.setProperty( Constants.PROPERTY_SHOW_OUTPUT_FILE, true );
    Context.setProperty( Constants.PROPERTY_SHOW_SUCCESS_MESSAGE, false );

    var modelVersion = Context.getProperty("modelVersion");
    
    var oRefModel = ArisData.getSelectedModels()[0];
    var oDB = ArisData.getActiveDatabase();

    var oCompModel;
    if (parseInt(modelVersion) != Number(modelVersion) || modelVersion <= 0) {
        // no valid version specified, get latest CL
        oCompModel = getCurrentModelVersion(oDB, oRefModel);
        if(oCompModel == null) {
            var errorMessage = "Model has no versions at all!";
            oCompModel = oRefModel;
        }
    } else {
        oDB = ArisData.openDatabaseVersion(oDB.Name(gn_Lang), modelVersion);
        oCompModel = oDB.FindGUID(oRefModel.GUID().toString(), Constants.CID_MODEL);    
    }
    
    var oComparisionSet = new __usertype_tComparisonSet( );
    var oUsrSettings = new cl_UISettings(oRefModel, [oRefModel, oCompModel]);
    oUsrSettings.CompModels = [oCompModel];
    oUsrSettings.getSettingsFromDesigner();
    //oUsrSettings.oCmpOptions = setComparisonOptions( oComparisionSet );
            
    // Printout documents
    oComparisionSet.getScope( oUsrSettings );
    oUsrSettings            = null;// Destroy oUsrSettings
    ga_Conditions           = getConditions();
    var aComparisonTable    = performComparision( oComparisionSet );// Perform comparision
    createDocument( oComparisionSet, aComparisonTable );// Write output report document
    
    Context.setProperty("success", "true");
    Context.setProperty("errorMessage", "");
    
// END::MAIN part----------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------


//-------------------------------------------------------------------------------------------------
// Functions part----------------------------------------------------------------------------------

/* function isStartedByDesigner() {
    var propFirstGuid = Context.getProperty("firstModelGuid");
    var propSecondGuid = Context.getProperty("secondModelGuid");
    var propFirstRev = Context.getProperty("firstRevision");
    var propSecondRev = Context.getProperty("secondRevision");
    
    if (propFirstGuid == null || propSecondGuid == null || propFirstRev == null || propSecondRev == null) return false;

    if (!ATSALL.isGuid(propFirstGuid)) return false;
    if (!ATSALL.isGuid(propSecondGuid)) return false;        
    if (isNaN(propFirstRev)) return false;
    if (isNaN(propSecondRev)) return false;        
        
    return true;
}*/

function getModelByProps(sPropGuid, sPropRev) {
    var sGuid = sPropGuid;//Context.getProperty(sPropGuid);
    var nRev = sPropRev;//parseInt(Context.getProperty(sPropRev));
    
    var oDB = ArisData.getActiveDatabase();
    if (nRev > 0) oDB = ArisData.openDatabaseVersion(oDB.Name(gn_Lang), nRev);
    
    return oDB.FindGUID(sGuid, Constants.CID_MODEL);
}


function getAttrValue( p_Obj, p_attrTypeNum, p_Lang ){
    if( (p_Obj != null) && (p_Obj.IsValid()) ){
        var oObj    = (p_Obj.KindNum() == Constants.CID_OBJOCC)?p_Obj.ObjDef():p_Obj;
        var p_Attr  = oObj.Attribute( p_attrTypeNum, p_Lang, true );
        if( (p_Attr.IsValid() == false) || (p_Attr.IsMaintained() == false) ){
            return null;
        }
        var aOut    = [];
            aOut["NAME"]    = java.lang.String( p_Attr.Type() );
        switch( ArisData.ActiveFilter().AttrBaseType( p_Attr.TypeNum() ) ){
            case Constants.ABT_MULTILINE:
                aOut["VALUE"]   = java.lang.String( p_Attr.GetValue(false) );
                break;
            case Constants.ABT_BOOL:
                aOut["VALUE"]   =  java.lang.Boolean.parseBoolean( p_Attr.GetValue(false) );
                break;
            case Constants.ABT_VALUE:
                aOut["VALUE"]   =  p_Attr.getValue();
                break;
            case Constants.ABT_SINGLELINE:
                aOut["VALUE"]   =  java.lang.String( p_Attr.GetValue(true) );
                break;
            case Constants.ABT_INTEGER:
                aOut["VALUE"]   =  parseInt( p_Attr.GetValue(false) );
                break;
            case Constants.ABT_RANGEINTEGER:
                aOut["VALUE"]   =  parseInt( p_Attr.GetValue(false) );
                break;
            case Constants.ABT_FLOAT:
                aOut["VALUE"]   =  parseFloat( p_Attr.GetValue(false) );
                break;
            case Constants.ABT_RANGEFLOAT:
                aOut["VALUE"]   =  parseFloat( p_Attr.GetValue(false) );
                break;
            case Constants.ABT_DATE:
                aOut["VALUE"]   =  p_Attr.getValueStd();
                break;
            case Constants.ABT_TIME:
                aOut["VALUE"]   =  p_Attr.getValueStd();
                break;
            case Constants.ABT_TIMESTAMP:
                aOut["VALUE"]   =  p_Attr.getValueStd();
                break;
            case Constants.ABT_TIMESPAN:
                aOut["VALUE"]   =  p_Attr.getValueStd();
                break;
            case Constants.ABT_FILE:
                aOut["VALUE"]   =  p_Attr.MeasureValue(false);
                break;
            case Constants.ABT_FOREIGN_ID:
                aOut["VALUE"]   =  p_Attr.GetValue(false);
                break;
            case Constants.ABT_COMBINED:
                aOut["VALUE"]   =  p_Attr.getMeasureValueAsString();
                break;
            case Constants.ABT_ITEMTYPE:
                aOut["VALUE"]   =  p_Attr.GetValue(false);
                break;
            case Constants.ABT_LONGTEXT:
                aOut["VALUE"]   =  p_Attr.MeasureValue(false);
                break;
            case Constants.ABT_BITMAP:
                aOut["VALUE"]   =  p_Attr.MeasureValue();
                break;
            case Constants.ABT_BLOB:
                aOut["VALUE"]   =  p_Attr.MeasureValue();
                break;
        }//END::switch()
        return aOut;
    }
}//END::getAttrValue()

function sortFilterNames( oA, oB ){
    var sA  = java.lang.String( oA.getName() );
    var sB  = java.lang.String( oB.getName() );
    return sA.compareToIgnoreCase( sB );
}

function sortStrings( sA, sB ){
    var jA  = java.lang.String(sA);
    var jB  = java.lang.String(sB);
    return jA.compareToIgnoreCase( jB );
}

function sortLangNames( oLA, oLB ){
    var sA  = java.lang.String( oLA.Name( gn_Lang ) );
    var sB  = java.lang.String( oLB.Name( gn_Lang ) );
    return sA.compareToIgnoreCase( sB );
}

function sortAttrNames( nNum1, nNum2 ){
    var sName1   = java.lang.String( ArisData.ActiveFilter().AttrTypeName( nNum1 ) );
    var sName2   = java.lang.String( ArisData.ActiveFilter().AttrTypeName( nNum2 ) );
    return sName1.compareToIgnoreCase( sName2 );
}

function sortChListID( oA, oB ){
    var nA  = oA.getID();
    var nB  = oB.getID();
    if( nA < nB ) return -1;
    if( nA > nB ) return 1;
    return 0;
}

function getAttrStrValue(p_objDef, p_attrTypeNum ){
    if( (p_objDef == null) || (!p_objDef.IsValid()) ){ return gs_Empty; }
    
    var oObj    = ((p_objDef.IsValid()) && (p_objDef.KindNum() == Constants.CID_OBJOCC) )?p_objDef.ObjDef():p_objDef;
    var attr    = oObj.Attribute(p_attrTypeNum, gn_Lang, true);
    
    if(!attr.IsValid() ){ return gs_Empty; }
    
    return java.lang.String( attr.GetValue(true) );
}//END::getAttrStrValue()


function getModelVersions( oModel ){
    var compVersioning = Context.getComponent("Versioning");
    if (compVersioning == null) return null;
    
    if( (oModel == null) || (!oModel.IsValid()) ) return null;
    
    var aModelVer = compVersioning.getModelRevisions( oModel );
    if (aModelVer.length == 0) { return null; }
    
    return aModelVer;
}//END::getModelRevisions()


function getProfileBool(sSection, sField, bDefault) {
    return (Context.getProfileInt(sSection, sField, bDefault?1:0) == 1);
}//END::getProfileBool()


function writeProfileBool(sSection, sField, bSet) {
    Context.writeProfileInt(sSection, sField, bSet?1:0);
}//END::writeProfileBool()


function isUserInDB( pCurrUser, pDBName ){
    try {
        var oDB = ArisData.openDatabase( pDBName, true );// OpenDB
    }catch(e) {
        // BLUE-4104
        return false;
    }    
    var aUserList   = oDB.UserList();
    for( var i=0; i<aUserList.length; i++ ){
        if( aUserList[i].Name( gn_Lang, true ).compareToIgnoreCase( pCurrUser ) == 0 ){
            oDB.close();
            return true;
        }
    }//END::for_i
    oDB.close();
    return false;
}


function createModelNames( aMods ){
    var aOut    = new Array();

    if( aMods != null ){
        for(var i=0; i<aMods.length; i++ ){
            aOut[i] = getModelName(aMods[i], gn_Lang);
        }//END::for_i
    }
    
    return aOut; 
}//END::createModelNames()


function transformModArrayToGUID( aMods ){
    var sOut    = gs_Empty;

    if( aMods != null ){
        for(var i=0; i<aMods.length; i++ ){
            if( aMods[i] != null ){
                sOut    = sOut.concat( aMods[i].GUID() );
                if( i< (aMods.length - 1) ){
                    sOut    = sOut.concat( ";" );
                }
            }
        }//END::for_i
    }
    
    return sOut;
}//END::transformModArrayToGUID()


function transformGUIDToModArray( oDB, sMods ){
    var aOut    = new Array();
    
    if( (oDB != null) && (sMods != null) ){
        var aMods   = sMods.split( ";" );
    
        for(var i=0; i<aMods.length; i++ ){
            var oMod    = oDB.FindGUID( aMods[i], Constants.CID_MODEL );
            if( (oMod != null) && (oMod.IsValid()) ){
                aOut.push( oMod );
            }
        }//END::for_i
    }

    if( (aOut != null) && (aOut.length > 0) ){
        return aOut;
    }

    return null;
}//END::transformGUIDToModArray()


function transformObjToGUID( oObj ){
    var sOut    = gs_Empty;
    if( (oObj != null) && (oObj.IsValid) ){
        sOut    = sOut.concat( oObj.GUID() );
    }
    return sOut;
}//END::transformObjToGUID()


function transformGUIDToObj( oDB, sObj, oCID ){
    if( (oDB != null) && (sObj != null) && (sObj.length() > 0) ){
        var oObj    = oDB.FindGUID( sObj, oCID );
        if( (oObj != null) && (oObj.IsValid()) ){
            return oObj;
        }
    }
    
    return null;
}//END::transformGUIDToObj()


function transformStringToArray( sStr ){
    var aOut    = new Array();
    
    if( (sStr != null ) && (sStr.length() > 0) ){
        aOut    = sStr.split( ";" );
    }
    
    if( (aOut != null) && (aOut.length > 0) ){
        return aOut;
    }

    return null;
}//END::transformStringToArray()


function transformArrayToString( aArray ){
    var sOut    = gs_Empty;
    if( (aArray != null) && (aArray.length > 0) ){
        for( var i=0; i<aArray.length; i++ ){
            sOut    = sOut.concat( aArray[i] );
            if( i < (aArray.length - 1) ) { sOut    = sOut.concat( ";" ); }
        }//END::for_i
    }
    return sOut;
}//END::transformArrayToString()


function transformOIDToModArray( oDB, sModels ){
    var aOut    = new Array();
    
    if( (oDB != null) && (sModels != null) ){
        var aModels   = sModels.split( ";" );
    
        for(var i=0; i<aModels.length; i++ ){
            var oModel  = oDB.FindOID( aModels[i] );
            if( (oModel != null) && (oModel.IsValid()) && (oModel.KindNum() == Constants.CID_MODEL ) ){
                aOut.push( oModel );
            }
        }//END::for_i
    }

    if( (aOut != null) && (aOut.length > 0) ){
        return aOut;
    }

    return null;
}

function tryLoginToDB( oUsrSettings, p_bReadOnly ){
    if (!gb_showDlg100) {
        // BLUE-4104
        oUsrSettings.CompDB = ArisData.openDatabase ( oUsrSettings.P11DBName, oUsrSettings.P10Login, oUsrSettings.P10Passwd, gs_Filter, gn_Lang, p_bReadOnly );
        if( oUsrSettings.CompDB != null ) return -1;// Return -1 as beeing OK
        return gn_errLogin;
    } 
    else {
        // oUsrSettings.CompDB = null;
        if( ( gs_Empty.compareToIgnoreCase( oUsrSettings.P11DBName ) != 0 ) &&
            ( gs_Empty.compareToIgnoreCase( oUsrSettings.P10Login ) != 0 ) &&
            ( gs_Empty.compareToIgnoreCase( oUsrSettings.P10Passwd ) != 0 ) &&
            ( oUsrSettings.P100Filter != null ) &&
            ( oUsrSettings.P100Lang != null ) &&
            ( (p_bReadOnly == true) || (p_bReadOnly == false) ) ){
            
            oUsrSettings.CompDB = ArisData.openDatabase ( oUsrSettings.P11DBName, oUsrSettings.P10Login, oUsrSettings.P10Passwd, oUsrSettings.P100Filter.getGUID(), oUsrSettings.P100Lang, p_bReadOnly );
        }
        
        if( oUsrSettings.CompDB != null ) return -1;// Return -1 as beeing OK
        return gn_errLogin;
    }
}

function getTableRowChecked( dialog, tabName, colNum, colRead ){
    var aOut        = new Array();
    if( (dialog != null) && (tabName != null) && (colNum != null) ){
        var tableName   = java.lang.String( tabName );
        if( tableName.length() > 0 ){
            var aTableValues    = dialog.getDlgListBoxArray( tableName );
            if( (aTableValues != null) && (aTableValues.length > 0) && (colNum > 0) && ((colNum <= aTableValues.length)) ){
                var nRows   = parseInt( aTableValues.length/ colNum );
                if( (colRead != null) && (colRead >= 0) && (colRead < parseInt(aTableValues.length/nRows)) ){
                    for( var i=0; i<nRows; i++ ){
                        if( (aTableValues[(i*colNum+colRead)] == 1) ){
                            return true;
                        }
                    }//END::for_i
                }
            }
        }
    }
    return false;
}

function setTableAllChecked( dialog, tabName, colNum, colRead, bChecked ){
    var aOut        = new Array();
    if( (dialog != null) && (tabName != null) && (colNum != null) ){
        var tableName   = java.lang.String( tabName );
        if( tableName.length() > 0 ){
            var aTableValues    = dialog.getDlgListBoxArray( tableName );
            if( (aTableValues != null) && (aTableValues.length > 0) && (colNum > 0) && ((colNum <= aTableValues.length)) ){
                var nRows   = parseInt( aTableValues.length/ colNum );
                if( (colRead != null) && (colRead >= 0) && (colRead < parseInt(aTableValues.length/nRows)) && (bChecked == true || bChecked == false) ){
                    for( var i=0; i<nRows; i++ ){
                        aTableValues[(i*colNum+colRead)]    = (bChecked == true)?1:0;
                    }//END::for_i
                    dialog.setDlgListBoxArray( tableName, aTableValues );
                    return true;
                }
            }
        }
    }
    return false;
}

function getWorkspaceModel( oDB, currModel) {   // AGA-4461
    var workspaceDB = ArisData.openDatabaseVersion( oDB.Name(gn_Lang), -1);
    
    var specifiedModel  = workspaceDB.FindGUID( currModel.GUID(), Constants.CID_MODEL );
    if(specifiedModel.IsValid()) {
        return [specifiedModel];
    }
    return gn_errNoCmp;
}

function getCurrentModelVersion( oDB, currModel) {  // AGA-4461
    var maxVersionID = getMaxVersionInfo(currModel);
    if (maxVersionID > 0) {
        var specifiedRevisionDB = ArisData.openDatabaseVersion( oDB.Name(gn_Lang), maxVersionID );
        if( specifiedRevisionDB != null ){
            var specifiedModel  = specifiedRevisionDB.FindGUID( currModel.GUID(), Constants.CID_MODEL );
            if(specifiedModel.IsValid()) {
                return specifiedModel;
            }
        }
    }
    return null;
}

function getMaxVersionInfo(currModel) {
	var maxVersionID = 0;
	var versioningComponent = Context.getComponent("Versioning");
    if (versioningComponent != null && currModel != null && currModel.IsValid()) {
		var mapModelToChangelist = versioningComponent.getLastModelChangeList([currModel]);
		if(mapModelToChangelist != null && mapModelToChangelist.keySet().contains(currModel) && mapModelToChangelist.get(currModel) != null) {
			maxVersionID = mapModelToChangelist.get(currModel);
		}
	} 
	return maxVersionID;  
}

function getModelSpecialRevisions( oDB, currModel, aVersions ){
    var aOut    = new Array();
    
    if( (oDB != null) && (aVersions != null) && (aVersions.length > 0) ){
        for( var i=0; i<aVersions.length; i++ ){
            var specifiedRevisionDB = ArisData.openDatabaseVersion( oDB.Name(gn_Lang), aVersions[i] );
            if( specifiedRevisionDB == null ){
                return gn_errNoDB;
            }

            var specifiedModel  = specifiedRevisionDB.FindGUID( currModel.GUID(), Constants.CID_MODEL );
            if( !specifiedModel.IsValid() ){
                return gn_errNoCmp;
            }
            if( specifiedModel.IsValid() ){
                aOut.push( specifiedModel );
            }
        }//END::for_i
    }

    return aOut;
}


function getConditions() {
    var aConditions = new Array();
    var fileData = Context.getFile("ModelComparison.xml", Constants.LOCATION_SCRIPT);
    var xmlReader = Context.getXMLParser(fileData);
    if (xmlReader.isValid()) {
        var xmlRoot = xmlReader.getRootElement();

        var xmlConditionList = xmlRoot.getChildren(c_xmlCondition);
        var iterCond = xmlConditionList.iterator();
        while (iterCond.hasNext()) {
            var xmlCondition = iterCond.next();
            
            var nsymboltype = getXmlAttrValue_TypeNum(xmlCondition, c_xmlSymbolType, Constants.CID_OBJOCC);
            var ncxntype    = getXmlAttrValue_TypeNum(xmlCondition, c_xmlCxnType, Constants.CID_CXNOCC);
            var nattrtype   = getXmlAttrValue_TypeNum(xmlCondition, c_xmlAttrType, Constants.CID_ATTRDEF);

            var xmlActionList = xmlCondition.getChildren(c_xmlAction);
            var iterAction = xmlActionList.iterator();
            while (iterAction.hasNext()) {
                var xmlAction = iterAction.next();

                var saction = getXmlAttrValue(xmlAction, c_xmlType);
                var smsgtext = getXmlAttrValue(xmlAction, c_xmlMsgText);
                
                aConditions.push(new __usertype_tConditions(nsymboltype, ncxntype, nattrtype, saction, smsgtext));
            }        
        }        
    }
    return aConditions;
    
    function getXmlAttrValue(xmlElement, sAttrName) {
        var xmlAttr = xmlElement.getAttribute(sAttrName)
        if (xmlAttr != null) return "" + xmlAttr.getValue();
        return "";
    }    
    
    function getXmlAttrValue_TypeNum(xmlElement, sAttrName, nKindNum) {
        var xmlAttr = xmlElement.getAttribute(sAttrName)
        if (xmlAttr != null) return  getTypeNum(xmlAttr.getValue(), nKindNum);
        return -1;
    }
    
    function getTypeNum(p_typeNum, p_kindNum) {
        if (String(p_typeNum).length == 0) return -1;
        
        var nTypeNum = p_typeNum;
        
        if (isNaN(p_typeNum)) {
            if (ATSALL.isGuid(p_typeNum)) {
                // userdefined attribute/model/symbol type number
                try {
                    if (p_kindNum == Constants.CID_ATTRDEF) return ArisData.ActiveFilter().UserDefinedAttributeTypeNum(p_typeNum);  
                    if (p_kindNum == Constants.CID_MODEL)  return ArisData.ActiveFilter().UserDefinedModelTypeNum(p_typeNum);
                    if (p_kindNum == Constants.CID_OBJOCC)  return ArisData.ActiveFilter().UserDefinedSymbolTypeNum(p_typeNum);
                } catch(e) {
                    return -1;
                }
                return -1;
            }
            nTypeNum = Constants[p_typeNum];
            if (typeof(nTypeNum) == "undefined" || isNaN(nTypeNum)) {
                return -1;
            }
        }
        return parseInt(nTypeNum);
    }
}


function getConditionMsgText(tMsgInput) {
    for (var i = 0; i < ga_Conditions.length; i++) {
        if (ga_Conditions[i].nsymboltype == tMsgInput.nsymboltype && 
            ga_Conditions[i].ncxntype == tMsgInput.ncxntype && 
            ga_Conditions[i].nattrtype == tMsgInput.nattrtype &&
            StrComp(ga_Conditions[i].saction, tMsgInput.saction) == 0) {
                
                return buildMsgText(ga_Conditions[i].smsgtext, tMsgInput);
        }
    }    
    if (tMsgInput.nattrtype > 0 && tMsgInput.ncxntype > 0) {
        if (StrComp(tMsgInput.saction, gs_Created) == 0) return buildMsgText(c_sDefaultText_CxnType_AttrTypeCreated, tMsgInput);
        if (StrComp(tMsgInput.saction, gs_Updated) == 0) return buildMsgText(c_sDefaultText_CxnType_AttrTypeUpdated, tMsgInput);
        if (StrComp(tMsgInput.saction, gs_Deleted) == 0) return buildMsgText(c_sDefaultText_CxnType_AttrTypeDeleted, tMsgInput);
    }
    if (tMsgInput.nattrtype > 0) {
        if (StrComp(tMsgInput.saction, gs_Created) == 0) return buildMsgText(c_sDefaultText_AttrTypeCreated, tMsgInput);
        if (StrComp(tMsgInput.saction, gs_Updated) == 0) return buildMsgText(c_sDefaultText_AttrTypeUpdated, tMsgInput);
        if (StrComp(tMsgInput.saction, gs_Deleted) == 0) return buildMsgText(c_sDefaultText_AttrTypeDeleted, tMsgInput);
    }
    if (tMsgInput.ncxntype > 0) {
        if (StrComp(tMsgInput.saction, gs_Created) == 0) return buildMsgText(c_sDefaultText_CxnTypeCreated, tMsgInput);
        if (StrComp(tMsgInput.saction, gs_Updated) == 0) return buildMsgText(c_sDefaultText_CxnTypeUpdated, tMsgInput);
        if (StrComp(tMsgInput.saction, gs_Deleted) == 0) return buildMsgText(c_sDefaultText_CxnTypeDeleted, tMsgInput);
    }
    if (tMsgInput.nsymboltype > 0) {        
        if (StrComp(tMsgInput.saction, gs_Created) == 0) return buildMsgText(c_sDefaultText_SymbolTypeCreated, tMsgInput);
        if (StrComp(tMsgInput.saction, gs_Updated) == 0) return buildMsgText(c_sDefaultText_SymbolTypeUpdated, tMsgInput);
        if (StrComp(tMsgInput.saction, gs_Deleted) == 0) return buildMsgText(c_sDefaultText_SymbolTypeDeleted, tMsgInput);
    }
    
    if (StrComp(tMsgInput.saction, gs_Created) == 0) return buildMsgText_Something(c_sDefaultText_SomethingCreated, tMsgInput);
    if (StrComp(tMsgInput.saction, gs_Updated) == 0) return buildMsgText_Something(c_sDefaultText_SomethingUpdated, tMsgInput);
    if (StrComp(tMsgInput.saction, gs_Deleted) == 0) return buildMsgText_Something(c_sDefaultText_SomethingDeleted, tMsgInput);

//    return "";

    function buildMsgText_Something(sMsgText, tMsgInput) {
        if (tMsgInput.omodel != null) {
            sMsgText = sMsgText.replace(/{model.reference.name}/g, getModelName(tMsgInput.omodel, gn_Lang));
        }
        if (tMsgInput.omodeltocompare != null) {
            sMsgText = sMsgText.replace(/{model.comparison.name}/g, getModelName(tMsgInput.omodeltocompare, gn_Lang));
        }
        
        var something = tMsgInput.oobjdef;
        if (something == null) something = tMsgInput.oobjdeftocompare;
        
        if (something != null && something.IsValid()) {
            switch( something.KindNum() ){
                case Constants.CID_GFXOBJ:
                    sMsgText = formatstring1(sMsgText, getString("TEXT_GRAPHIC_OBJECT"));
                    break;
                case Constants.CID_TEXTDEF:
                case Constants.CID_TEXTOCC:
                    sMsgText = formatstring1(sMsgText, getString("TEXT_FREE_FORM_TEXT"));
                    break;
                case Constants.CID_COMOBJDEF:
                case Constants.CID_COMOBJOCC:
                    sMsgText = formatstring1(sMsgText, getString("TEXT_OLE_OBJECT"));
                    break;
                default:
                    // BLUE-4616
                    sMsgText = formatstring1(sMsgText, getString("TEXT_ATTRIBUTE"));
            }
        }
        return sMsgText;
    }
    
    function buildMsgText(sMsgText, tMsgInput) {
        if (tMsgInput.omodel != null) {
            sMsgText = sMsgText.replace(/{model.reference.name}/g, getModelName(tMsgInput.omodel, gn_Lang));
            sMsgText = sMsgText.replace(/{model.type}/g, tMsgInput.omodel.Type());
        }
        if (tMsgInput.omodeltocompare != null) {
            sMsgText = sMsgText.replace(/{model.comparison.name}/g, getModelName(tMsgInput.omodeltocompare, gn_Lang));
            sMsgText = sMsgText.replace(/{model.type}/g, tMsgInput.omodeltocompare.Type());
        }
        if (tMsgInput.oobjdef != null) {
            sMsgText = sMsgText.replace(/{object.reference.name}/g, tMsgInput.oobjdef.Name(gn_Lang));
            sMsgText = sMsgText.replace(/{object.type}/g, tMsgInput.oobjdef.Type());
        }            
        if (tMsgInput.oobjdeftocompare != null) {
            sMsgText = sMsgText.replace(/{object.comparison.name}/g, tMsgInput.oobjdeftocompare.Name(gn_Lang));
            sMsgText = sMsgText.replace(/{object.type}/g, tMsgInput.oobjdeftocompare.Type());
        }
        if (tMsgInput.oattr != null) {
             sMsgText = sMsgText.replace(/{attribute.reference.value}/g, tMsgInput.oattr.GetValue(true));
             sMsgText = sMsgText.replace(/{attribute.type}/g, tMsgInput.oattr.Type());
        }
        if (tMsgInput.oattrtocompare != null) {
             sMsgText = sMsgText.replace(/{attribute.comparison.value}/g, tMsgInput.oattrtocompare.GetValue(true));
             sMsgText = sMsgText.replace(/{attribute.type}/g, tMsgInput.oattrtocompare.Type());
        }
        if (tMsgInput.ocxndef != null) {
             sMsgText = sMsgText.replace(/{cxn.reference.sourcename}/g, tMsgInput.ocxndef.SourceObjDef().Name(gn_Lang));
             sMsgText = sMsgText.replace(/{cxn.reference.targetname}/g, tMsgInput.ocxndef.TargetObjDef().Name(gn_Lang));             
             sMsgText = sMsgText.replace(/{cxn.type}/g, tMsgInput.ocxndef.ActiveType());
        }
        if (tMsgInput.ocxndeftocompare != null) {
             sMsgText = sMsgText.replace(/{cxn.comparison.sourcename}/g, tMsgInput.ocxndeftocompare.SourceObjDef().Name(gn_Lang));
             sMsgText = sMsgText.replace(/{cxn.comparison.targetname}/g, tMsgInput.ocxndeftocompare.TargetObjDef().Name(gn_Lang));             
             sMsgText = sMsgText.replace(/{cxn.type}/g, tMsgInput.ocxndeftocompare.ActiveType());
        }
        return sMsgText;
    }
}


function isAttributeToIgnore( oAttr ){
    var nTypeNum    = oAttr.TypeNum();
    if( ArisData.ActiveFilter().AttrProperties( nTypeNum )& 1){
        return false;// Attribute is visible - so not hidden - Will NOT BE ignored
    }
    return true;// Attribute is hidden - WILL BE ignored
}


function doCheck( aItems ){
    var nCount  = 0;
    for( var i=0; i<aItems.length; i++ ){
        if( aItems[i] != null ) nCount++;
        if( nCount >= 2 ) return true;
    }// END::for_i
    return false;
}


function getNullArray() {
    var aNullArray  = new Array();
    for( var i=0; i<gn_ModelCount; i++ ){
        aNullArray[i]   = null;
    }//END::for_i
    return aNullArray;
}

function setComparisonOptions( oComparisionSet ){
    var oCmpOptions = oComparisionSet.oRefModel.createEmptyComparisonOptions();
    
    oCmpOptions.setItemExistingOnlyInFirstModel(getBoolPropertyValue("itemExistingOnlyInFirstModel"));
    oCmpOptions.setItemExistingOnlyInSecondModel(getBoolPropertyValue("itemExistingOnlyInSecondModel"));
    oCmpOptions.setModifiedItemsExistingInBothModel(getBoolPropertyValue("modifiedItemsExistingInBothModel"));

    oCmpOptions.setModelProperties(getBoolPropertyValue("modelProperties"));

    oCmpOptions.setObjectDefinition(getBoolPropertyValue("objectDefinition"));
    oCmpOptions.setObjectAttributes(getBoolPropertyValue("objectAttributes"));
    oCmpOptions.setObjectSystemAttributes(getBoolPropertyValue("objectSystemAttributes"));
    oCmpOptions.setObjectOccurrences(getBoolPropertyValue("objectOccurrences"));
    oCmpOptions.setObjectAppearence(getBoolPropertyValue("objectAppearence"));
    oCmpOptions.setObjectPositionSize(getBoolPropertyValue("objectPositionSize"));
    oCmpOptions.setObjectAttributePlacements(getBoolPropertyValue("objectAttributePlacements"));
    
    oCmpOptions.setConnectionDefinition(getBoolPropertyValue("connectionDefinition"));
    oCmpOptions.setConnectionAttributes(getBoolPropertyValue("connectionAttributes"));
    oCmpOptions.setConnectionOccurrences(getBoolPropertyValue("connectionOccurrences"));
    oCmpOptions.setConnectionAppearences(getBoolPropertyValue("connectionAppearences"));
    oCmpOptions.setConnectionPoints(getBoolPropertyValue("connectionPoints"));
    oCmpOptions.setConnectionAttributePlacements(getBoolPropertyValue("connectionAttributePlacements"));

    oCmpOptions.setGfxObjects(getBoolPropertyValue("gfxObjects"));
    oCmpOptions.setOleObjects(getBoolPropertyValue("oleObjects"));
    oCmpOptions.setFreeformtTexts(getBoolPropertyValue("freeformtTexts"));
    
    /*
	var sAttrIdentify = getAttrPropertyValue("setAttributeIdentify");
	cmpOptions.AddIdenticalAttr = (parseInt(sAttrIdentify) > 0);
	if( cmpOptions.AddIdenticalAttr ){
		cmpOptions.AddAttrNumber = sAttrIdentify;
		cmpOptions.AddMatchCase = getBoolPropertyValue("setCaseSensitive");
		cmpOptions.AddLineBreaksSpaces = getBoolPropertyValue("setIncludeLineBreaks");
	}
	*/
    
    oCmpOptions.setMasterVariantModelComparison(false);
    return oCmpOptions;
}

function getBoolPropertyValue(p_sPropKey) {
    var property = Context.getProperty(p_sPropKey);
    if (property != null) {
        return (StrComp(property, "true") == 0);
    }
    return false;
}

function performComparision( oComparisionSet ){
    var aComparisonTable    = new Array();

    if( (oComparisionSet.oRefModel != null) && (oComparisionSet.aCompModels != null) && (gn_ModelCount > 0) ){
        var oCmpOptions         = setComparisonOptions( oComparisionSet );

        for( var i=0; i<gn_ModelCount; i++){
            var oCmpDifferences = oComparisionSet.oRefModel.compareModel( oComparisionSet.aCompModels[i], gn_Lang, oCmpOptions );
            parseComparisonDifferences( oCmpDifferences, aComparisonTable, oComparisionSet, i+1 );
            if( i==0 ){
                ga_ModelGraphic.push( oCmpDifferences.getFirstModelGraphic( true, false, gn_Lang ) );
            }
            ga_ModelGraphic.push( oCmpDifferences.getSecondModelGraphic( true, false, gn_Lang ) );
        }// END::for_i
    }

    return aComparisonTable.sort( sortByRefName );
    
    function parseComparisonDifferences( oCmpDifferences,  aComparisonTable, oComparisionSet, colIndex ){
        var aDifferences    = oCmpDifferences.getDifferences();
        for( var i=0; i<aDifferences.length; i++ ){
            var oDifference = aDifferences[i];
            
            var oExistingElement = oDifference.getExistingElement();            // AGA-5835
            if (oExistingElement == null || !oExistingElement.IsValid() ) {
                continue;
            }
            if( checkIncluded( oDifference ) ){
                var rowIndex    = getTableRow( oDifference, aComparisonTable, oComparisionSet, colIndex );
                if( aComparisonTable[ rowIndex ].aElements[ colIndex ] == null ){
                    aComparisonTable[ rowIndex ].aElements[ colIndex ]  = setRightSubDifference( oDifference, oComparisionSet, colIndex );
                }
            }
        }// END::for_i
    }
    
    function getTableRow( oDifference, aComparisonTable, oComparisionSet, colIndex ){
        for( var i=0; i<aComparisonTable.length; i++ ){
            for( var j=0; j<colIndex; j++ ){
                if( !doCheck( aComparisonTable[ i ].aElements ) ) break;
                if( isEqual( oDifference, aComparisonTable[ i ].oRefObj, aComparisonTable[ i ].aElements[ j ], oComparisionSet) ) { return i; }
            }// END::for_j
        }// END::for_i

        aComparisonTable.push( setMainDifference( oDifference, oComparisionSet ) );
        var rIndex  = aComparisonTable.length - 1;
        aComparisonTable[ rIndex ].aElements[ 0 ]  = setSubDifference( oDifference, oComparisionSet, colIndex );
        
        return rIndex;
    }
    
    function isElementItem(oElement) {
        if (oElement != null) {
            switch (oElement.KindNum()) {        
                case Constants.CID_MODEL:
                case Constants.CID_OBJDEF:
                case Constants.CID_CXNDEF:
                //case Constants.CID_COMOBJDEF:
                case Constants.CID_TEXTDEF:
                    return true;
            }
        }
        return false;
    }
    
    function getElementItem(oElement) {
        if (oElement != null) {
            if (isElementItem(oElement)) return oElement;
            switch (oElement.KindNum()) {        
                case Constants.CID_OBJOCC:
                    return oElement.ObjDef();
                case Constants.CID_CXNOCC:
                    return oElement.CxnDef();
                case Constants.CID_TEXTOCC:
                    return oElement.TextDef();
            }
        }
        return null; // (CID_COMOBJDEF,) CID_COMOBJOCC, CID_GFXOBJ
    }
       
    function getSubElementValue(Flag, oDifference) {
        var oSubElement = getRightLeftSubElement( null, oDifference);
        if (oSubElement != null && oSubElement.IsValid() && oSubElement.KindNum() == Constants.CID_ATTRDEF) {
            var oElementItem = getElementItem(getRightLeftElement( Flag, oDifference));
            if (oElementItem != null) {
                var nAttrTypeNum = oSubElement.TypeNum();   // SubElement is always attribute (def or occ)
                if (nAttrTypeNum!= null) {

                    return oElementItem.Attribute(nAttrTypeNum, gn_Lang).getValue();
                }
            }
        }
        if (Flag != null) {
            return (Flag == "LEFT") ? oDifference.getValueDescriptionLeft() : oDifference.getValueDescriptionRight();
        }
        return oDifference.getValueDescriptionLeft();
    }
    
    function setSubDifference( oDifference, oComparisionSet, colIndex ){// Create Referrence element for aElements array for 0-position
        var oElement    = new __cl_SubElement( getRightLeftElement( "LEFT", oDifference), getRightLeftSubElement( null, oDifference), oDifference.getElementDescriptionLeft(),oDifference.isSubElementChanged(), oDifference.getDifferenceType(), oDifference.getDifferenceKind(), oDifference.getDifferenceDescription(), getSubElementValue("LEFT", oDifference) );
        return oElement;
    }

    function setRightSubDifference( oDifference, oComparisionSet, colIndex ){// Create elements for aElements array
        var oElement    = new __cl_SubElement( getRightLeftElement( "RIGHT", oDifference), getRightLeftSubElement( "RIGHT", oDifference), oDifference.getElementDescriptionRight(),oDifference.isSubElementChanged(), oDifference.getDifferenceType(), oDifference.getDifferenceKind(), oDifference.getDifferenceDescription(), getSubElementValue("RIGHT", oDifference) );
        oComparisionSet.oCmpStatistics.Set( oDifference );
        var msgInput    = createMsgInput( oDifference, oComparisionSet, colIndex );
        ga_Summary.push( new __usertype_tSummaryEntry( getConditionMsgText(msgInput), "", msgInput.saction ) );
        return oElement;
    }

    function setLeftSubDifference( oDifference, oComparisionSet, colIndex ){// Create Referrence element for aElements array for 0-position
        var oElement    = new __cl_SubElement( getRightLeftElement( "LEFT", oDifference), getRightLeftSubElement( "LEFT", oDifference), oDifference.getElementDescriptionLeft(),oDifference.isSubElementChanged(), oDifference.getDifferenceType(), oDifference.getDifferenceKind(), oDifference.getDifferenceDescription(), getSubElementValue("LEFT", oDifference) );
        //oComparisionSet.oCmpStatistics.Set( oDifference );
        //var msgInput    = createMsgInput( oDifference, oComparisionSet, colIndex );
        //ga_Summary.push( new __usertype_tSummaryEntry( getConditionMsgText(msgInput), "", msgInput.saction ) );
        return oElement;
    }

    function setMainDifference( oDifference, oComparisionSet ){// Create elements for aComparisonTable
        var sName = oDifference.getElementDescriptionLeft();
        if (sName == "") sName = oDifference.getElementDescription();
        var oElement    = new __cl_MainElement( oDifference.getExistingElement(), sName, oDifference.isSubElementChanged(), oDifference.getElementType(), oDifference.getDifferenceType(), oDifference.getDifferenceKind(), oDifference.getDifferenceDescription(), getNullArray() );
            //oComparisionSet.oCmpStatistics.Set( oDifference );
        return oElement;
    }
    
    function getRightLeftElement( Flag, oDifference){
        if( (Flag != null) && (Flag == "LEFT") ){
            return oDifference.getLeft();
        }
        if( (Flag != null) && (Flag == "RIGHT") ){
            return oDifference.getRight();
        }
        return oDifference.getExistingElement();
    }
    
    function getRightLeftSubElement( Flag, oDifference ){
        if( (Flag != null) && (Flag == "LEFT") ){
            return oDifference.getSubElementLeft();
        }
        if( (Flag != null) && (Flag == "RIGHT") ){
            return oDifference.getSubElementRight();
        }
        if( oDifference.getSubElementLeft() == null ){
            return oDifference.getSubElementRight();
        }
        return oDifference.getSubElementLeft();
    }
    
    function isEqual( oDifference, oRefObj, oSubElement, oComparisionSet ){// oDifference, aComparisonTable[ i ].oRefObj, aComparisonTable[ i ].aElements[ j ]
        var oElementA = oDifference.getExistingElement();
        var oElementB = oRefObj;
        if (isSameElement(oElementA, oElementB, oComparisionSet)) {
            if( !oDifference.isSubElementChanged() ){
                return true;
            }
            if( oDifference.isSubElementChanged() && (oSubElement != null) && (oSubElement.oSubObj != null) ){// Attribute object compare
                var oSubElementA = oSubElement.oSubObj;
                var oSubElementB = getRightLeftSubElement( null, oDifference);
                if (isSameSubElement(oSubElementA, oSubElementB)) {
                    return true;
                }
            }
        }
        return false;
        
        function isSameElement(oElementA, oElementB, oComparisionSet) {
            if (oElementA.equals(oElementB)) return true;

            if (oElementA.KindNum() == oElementB.KindNum()) {
                if (oElementA.KindNum() == Constants.CID_OBJDEF || oElementA.KindNum() == Constants.CID_OBJOCC) {
                    return isSameObjDef(oElementA, oElementB, oComparisionSet);
                }
                if (oElementA.KindNum() == Constants.CID_CXNDEF || oElementA.KindNum() == Constants.CID_CXNOCC) {
                    return isSameCxnDef(oElementA, oElementB, oComparisionSet);
                }
            }
            return false;

            function isSameObjDef(oElementA, oElementB, oComparisionSet) {
                var oObjDefA = getDefinition(oElementA)
                var oObjDefB = getDefinition(oElementB)

                if (oObjDefA.TypeNum() == oObjDefB.TypeNum()) {
                    // same object
                    if (oObjDefA.equals(oObjDefB)) return true;
                    // same Guid
                    if (oObjDefA.GUID().equals(oObjDefB.GUID())) return true;
                    // same RefGuid
                    if (oComparisionSet.oCmpOptions.MasterVariantComp == true) {
                        if (oObjDefA.GUID().equals(oObjDefB.RefGUID()) ||
                            oObjDefA.RefGUID().equals(oObjDefB.GUID())) return true;
                    }
                    // same attr value
                    if (oComparisionSet.oCmpOptions.AddIdenticalAttr == true) {
                        var nAttrTypeNum = oComparisionSet.oCmpOptions.AddAttrNumber;
                        
                        var sAttrValueA = oObjDefA.Attribute(nAttrTypeNum, gn_Lang).GetValue(false);
                        var sAttrValueB = oObjDefB.Attribute(nAttrTypeNum, gn_Lang).GetValue(false);
                        
                        if (!oComparisionSet.oCmpOptions.AddMatchCase) {
                            // not case-sensitve
                            sAttrValueA = doToLowerCase(sAttrValueA);
                            sAttrValueB = doToLowerCase(sAttrValueB);
                        }
                        if (!oComparisionSet.oCmpOptions.AddLineBreaksSpaces) {
                            // no line breakes and spaces
                            sAttrValueA = removeblanksfromname(sAttrValueA);
                            sAttrValueB = removeblanksfromname(sAttrValueB);
                        }
                        if (StrComp(sAttrValueA, sAttrValueB) == 0) return true;
                    }
                }
                return false;
                
                function removeblanksfromname(sname1) {
                    var  result = doReplace(sname1, " ", "");
                    result = doReplace(result, "\r\n", "");
                    result = doReplace(result, "\r"  , "");
                    result = doReplace(result, "\n"  , "");
                    return result;
                }
            }
            
            function isSameCxnDef(oElementA, oElementB, oComparisionSet) {
                var oCxnDefA = getDefinition(oElementA)
                var oCxnDefB = getDefinition(oElementB)
                
                if (oCxnDefA.TypeNum() == oCxnDefB.TypeNum()) {
                    // same source object and same target object
                    return (isSameObjDef(oCxnDefA.SourceObjDef(), oCxnDefB.SourceObjDef(), oComparisionSet) &&
                            isSameObjDef(oCxnDefA.TargetObjDef(), oCxnDefB.TargetObjDef(), oComparisionSet));
                }
                return false;
            }
        }
        
        function isSameSubElement(oSubElementA, oSubElementB) {
            if( oSubElementA.equals(oSubElementB)) {
                return true; 
            }
            if (oSubElementA != null && oSubElementB != null && oSubElementA.IsValid() && oSubElementB.IsValid()) {
                if (oSubElementA.KindNum() == Constants.CID_ATTRDEF && oSubElementB.KindNum() == Constants.CID_ATTRDEF) {
                    return (oSubElementA.TypeNum() == oSubElementB.TypeNum());
                }
                if (oSubElementA.KindNum() == Constants.CID_ATTROCC && oSubElementB.KindNum() == Constants.CID_ATTROCC) {
                    return (oSubElementA.AttrDef().TypeNum() == oSubElementB.AttrDef().TypeNum());
                }
            }
            return false;
        }
    }
    
    
    function checkIncluded( oDifference ){
        switch( oDifference.getDifferenceType() ){// Get Existence OR Difference
            case Constants.MODCOMP_DIFF_LEFTONLY:// Existence
            case Constants.MODCOMP_DIFF_RIGHTONLY:// Existence
                break;
            case Constants.MODCOMP_DIFF_BOTH:// Difference
                if( oDifference.isSubElementChanged() ){// Get Difference in Attribute 
                    var oAttr   = getRightLeftSubElement( null, oDifference );
                    if( oAttr != null && oAttr.IsValid() ){// Change after method KindNum() available for attributes: if( (oAttr != null) && ( (oAttr.KindNum == Constants.CID_ATTRDEF) || (oAttr.KindNum == Constants.CID_ATTROCC) ) ){
                        return !( isAttributeToIgnore( getRightLeftSubElement( null, oDifference ) ) );
                    }
                } else {// Get Difference in Existence, appearance, size, position,...
                    switch( oDifference.getExistingElement().KindNum() ){
                        case Constants.CID_OBJDEF:
                        case Constants.CID_OBJOCC:
                            break;
                        case Constants.CID_CXNDEF:
                        case Constants.CID_CXNOCC:
                            break;
                        case Constants.CID_COMOBJDEF:
                        case Constants.CID_COMOBJOCC:
                            break;
                        case Constants.CID_TEXTDEF:
                        case Constants.CID_TEXTOCC:
                            break;
                        case Constants.CID_GFXOBJ:
                            break;
                    }// END::switch_KindNum
                }
                break;
        }// END::switch_getDifferenceType
        return true;
    }
    
    function sortByRefName( a, b ){
        return StrComp( a.sName , b.sName );
    }
    
    function createMsgInput( oDifference, oComparisionSet, colIndex ){
        var oObj        = getRightLeftElement( null, oDifference );
        var msgInput    = new __usertype_tMsgInput();

        // default
        var elemRef     = oDifference.getLeft();
        var elemCmp     = oDifference.getRight();
        var subelemRef  = oDifference.getSubElementLeft();
        var subelemCmp  = oDifference.getSubElementRight();
        
        var modelRef    = oComparisionSet.oRefModel;
        var modelCmp    = oComparisionSet.aCompModels[(colIndex-1)];
        
        if ( (oComparisionSet.nModCompare == 0) && doChangeReference(modelRef, modelCmp) ) {
            // BLUE-7507 Comparison of versioned models must be relative to the (older) version
            elemRef     = oDifference.getRight();
            elemCmp     = oDifference.getLeft();
            subelemRef  = oDifference.getSubElementRight();
            subelemCmp  = oDifference.getSubElementLeft();
            
            modelRef    = oComparisionSet.aCompModels[(colIndex-1)];
            modelCmp    = oComparisionSet.oRefModel;
        }
        
        msgInput.nsymboltype        = getSymbolNum( oDifference, oComparisionSet.aCompModels[(colIndex-1)] );
        msgInput.omodel             = modelRef;
        msgInput.omodeltocompare    = modelCmp;        

        if (isCxn(oDifference)) {
            // Anubis 541120
            msgInput.ocxndef            = getDefinition( elemRef );
            msgInput.ocxndeftocompare   = getDefinition( elemCmp );
            msgInput.ncxntype           = (msgInput.ocxndef != null) ? msgInput.ocxndef.TypeNum() : msgInput.ocxndeftocompare.TypeNum();
        } else {
            msgInput.oobjdef            = getDefinition( elemRef );
            msgInput.oobjdeftocompare   = getDefinition( elemCmp );
        }        
        switch( oDifference.getDifferenceType() ){// Get Existence OR Difference
            case Constants.MODCOMP_DIFF_LEFTONLY:
            case Constants.MODCOMP_DIFF_RIGHTONLY:
                msgInput.saction    = getAction( elemRef, elemCmp );
                break;
            case Constants.MODCOMP_DIFF_BOTH:// Difference
                if( oDifference.isSubElementChanged() ){//  Write Attribute difference message input
                    msgInput.saction    = getAction( subelemRef, subelemCmp );
                    var oAttr   = getRightLeftSubElement( null, oDifference );
                    if( (oAttr != null && oAttr.IsValid()) && ( isAttributeToIgnore( getRightLeftSubElement( null, oDifference ) ) == false) ){
                        msgInput.nattrtype      = (oAttr.KindNum() == Constants.CID_ATTROCC)?oAttr.AttrTypeNum():oAttr.TypeNum();                                    
                        msgInput.oattr          = subelemRef;
                        msgInput.oattrtocompare = subelemCmp;       // BLUE-11804
                    }
                } else {// Get Difference in Existence, appearance, size, position,...
                    msgInput.saction    = getAction( elemRef, elemCmp );
                }
                break;
        }// END::switch_getDifferenceType

        return msgInput;
        
        function isCxn(oDifference) {
            var oObject = oDifference.getLeft();
            if (oObject == null) oObject = oDifference.getRight();             
            
            if (oObject != null) {
                if (oObject.KindNum() == Constants.CID_CXNDEF || 
                    oObject.KindNum() == Constants.CID_CXNOCC) return true;
            }
            return false;
        }
        
        function doChangeReference(modelRef, modelCmp) {
            refVersion = modelRef.Database().getVersion();
            cmpVersion = modelCmp.Database().getVersion();
            
            if (refVersion == -1) return true;
            if (cmpVersion == -1) return false;
            
            return (refVersion > cmpVersion);
        }
    }
    
    function getAction( leftObject, rightObject ){
        if( leftObject == null && rightObject != null ) return gs_Created;
        if( leftObject != null && rightObject == null ) return gs_Deleted;
        return gs_Updated;
    }
    
    function getSymbolNum( oDifference, oCompModel ){
        var oObj    = (oDifference.isSubElementChanged() == true)?getRightLeftSubElement(null, oDifference):getRightLeftElement(null, oDifference );
        if( oObj != null && oObj.IsValid() ) {
            switch( oObj.KindNum() ){
                case Constants.CID_OBJDEF:  
                    var oOcc    = getOccOfDefinition( oObj, [oCompModel] );
                    return ( (oOcc != null)? oOcc.SymbolNum(): "");
                    break;
                case Constants.CID_OBJOCC:
                    return oObj.SymbolNum();
                    break;
            }// END::switch_KindNum
        }
        return "";
    }

    function getDefinition( oObj ){
        if( oObj != null && oObj.IsValid() ){
            switch( oObj.KindNum() ){
                case Constants.CID_ATTROCC:
                    return oObj.AttrDef( gn_Lang );
                    break;
                case Constants.CID_OBJOCC:
                    return oObj.ObjDef();
                    break;
                case Constants.CID_CXNOCC:
                    return oObj.CxnDef();
                    break;
            }// END::switch_KindNum
        }
        return oObj;
    }
    
    function getOccOfDefinition( oDef, aModels ){
        for( var i=0; i<aModels.length; i++ ){
            var oOccListInModel = oDef.OccListInModel( aModels[i] );
            if (oOccListInModel.length > 0) return oOccListInModel[0];
        }//END::for_i
        return null;
    }
    
}//END::performComparision()


function createDocument( oComparisionSet, aComparisonTable ){
    var outFile = Context.createOutputObject( Context.getSelectedFormat( ), gs_FileName );
        outFile.Init( gn_Lang );
    if (isVersionable){
        defineStyles( outFile );
        createSummaryStatistics( outFile, oComparisionSet );
        createComparisonStatements( outFile );
        createDetailedOutput( outFile, oComparisionSet, aComparisonTable );
        createGraphicOutputPreparation( outFile, oComparisionSet );//prepares for createGraphicOutputUsingExcel
        outFile.WriteReport( );    
        createGraphicOutputUsingExcel(outFile, gs_FileName, oComparisionSet)
    } else {
        defineStyles( outFile );
        outFile.BeginTable( 100, CC_BLACK, CC_WHITE, Constants.FMT_VCENTER | Constants.FMT_REPEAT_HEADER, 0 );
        outFile.TableRow( );
        addCell( outFile, [1,1,1,1], "Model doesn't have any versions!", 35, "TEXT_STYLE_DEFAULT" );
        outFile.EndTable( getString("TABNAME_SUMMARY"), 100, getString("TEXT_FONT_DEFAULT"), 8, CC_TRANSPARENT, CC_TRANSPARENT, Constants.FILLTYPE_SOLID, Constants.FMT_LEFT, 0);
        outFile.WriteReport( );
    }
    
}//END::createDocument()

function resizePicture( p_Output, p_Pict, p_MaxSize ){
    var nPicWidth   = p_Pict.getWidth(Constants.SIZE_LOMETRIC) / 10 ;
    var nPicHeight  = p_Pict.getHeight(Constants.SIZE_LOMETRIC) / 10 ;
    var nDispWidth  = ( p_MaxSize[0] != "" )?p_MaxSize[0]:p_Output.GetPageWidth() - p_Output.GetLeftMargin() - p_Output.GetRightMargin();
    var nDispHeight = ( p_MaxSize[1] != "" )?p_MaxSize[1]:p_Output.GetPageHeight() - p_Output.GetTopMargin() - p_Output.GetBottomMargin() - 30;
    var aSize       = new Array();
    var nZoom       = 1;
    aSize["PAGE"]   = false;
    
    if( nDispHeight < nPicHeight ) { aSize["PAGE"]  = true; }
    
    aSize["WIDTH"]  = (nPicWidth / nZoom).toFixed(2);
    aSize["HEIGHT"] = (nPicHeight / nZoom).toFixed(2);
    
    return aSize;
}//END::resizePicture()

// END::Functions part-----------------------------------------------------------------------------

// Classes-----------------------------------------------------------------------------------------
function cl_MasterVariant( ){
        this.oMaster    = null;
        this.aVariants  = null;
        
        cl_MasterVariant.prototype.getMaster    = function( oModel, oDB, bFlag ){
            if( (oModel == null) || (oDB == null) || (!oModel.IsValid()) || (!oDB.IsValid()) || ((bFlag != 0) && (bFlag != 1) ) ) { return; }
            
            if( bFlag == 0 ){// Perform on ActiveDB
                var oObj    = oModel.Master();
                if( oObj.IsValid() ){
                    this.oMaster    = oObj;
                }
            }
            if( bFlag == 1 ){// Perform on Comparison DB
                var srchGUID    = oModel.RefGUID();
                if( (srchGUID != null) && (srchGUID.length() > 0) ){
                    var masterModel = oDB.FindGUID( srchGUID, Constants.CID_MODEL );
                    if( (masterModel != null) && (masterModel.IsValid()) ){
                        this.oMaster    = masterModel;
                    }
                }
            }
        }
        
        cl_MasterVariant.prototype.getVariants  = function( oModel, oDB, bFlag ){
            if( (oModel == null) || (oDB == null) || (!oModel.IsValid()) || ((bFlag != 0) && (bFlag != 1) ) ) { return; }
            
            if( bFlag == 0 ){// Perform on ActiveDB
                if( oModel.Variants().length > 0 ){
                    this.aVariants  = oModel.Variants();
                    this.aVariants.sort( sortLangNames );
                }
            }
            if( bFlag == 1 ){// Perform on Comparison DB
                var srchGUID    = oModel.GUID();
                if( (srchGUID != null) && (srchGUID.length() > 0) ){
                    var aVariants   = oDB.FindRefGUID( srchGUID, Constants.CID_MODEL );
                    if( (aVariants != null) && (aVariants.length > 0) ){
                        this.aVariants  = aVariants;
                        this.aVariants.sort( sortLangNames );
                    }
                }
            }
        }

        cl_MasterVariant.prototype.Initialize   = function( oModel, oDB, bFlag ){
                this.getMaster( oModel, oDB, bFlag );
                this.getVariants( oModel, oDB, bFlag );
        }
        
        cl_MasterVariant.prototype.HasMaster    = function(){
            if( this.oMaster != null ){
                return true;
            }
            return false;
        }
        cl_MasterVariant.prototype.HasVariant  = function(){
            if( (this.aVariants != null) && (this.aVariants.length > 0) ){
                return true;
            }
            return false;
        }
        
        cl_MasterVariant.prototype.HasMasterVariants    = function(){
            if( this.HasMaster() || this.HasVariant() ){
                return true;
            }
            return false;
        }
        cl_MasterVariant.prototype.outModels    = function(){
            var aOut    = new Array();
            if( this.HasMaster() ){
                aOut.push( this.oMaster );
            }
            if( this.HasVariant() ){
                aOut    = aOut.concat( this.aVariants );
            }
            return aOut;
        }
}//END::CL_MASTERVARIANT


function cl_UISettings( referenceModel, selectedModels ){
    this.aModels        = (selectedModels != null)?selectedModels:null;// Selected models on which report was started
    this.RefModel       = (referenceModel != null)?referenceModel:null;// Reference model
    this.RefVersioned   = false;                // Flag whether ref.model is versioned
    this.CompModels     = [];                   // Array of selected models for comparision
    this.CompDB         = null;                 // Cross compare DB opened using P10Login, P10Password, P100Filter, P100Lang, as read-only
    //Page #11 - Only one model selected
    this.P11DBCompare   = 0;                    // Option for comparison of models: 0->Within One DB, 1->Cross DB comparision
    this.P11DBName      = gs_Empty;             // Database name for db compare
    this.P11ModCompare  = 0;                    // Option for comparison of models: 0->Versions, 1->Masters/variants, 2->Attribute, 3->GUID, 4->Selected models
    this.P11AttrNumber  = Constants.AT_NAME;    // Attribute type num for model comparison by attribute
    this.P11MatchCase   = false;                // Flag for case sensitive attribute comparison for models
    //SubPage #10 - Login into DB
    this.P10Login       = gs_Empty;             // Database user login name
    this.P10Passwd      = gs_Empty;             // Database password
    //SubPage #100 - Login Options
    this.P100Filter     = null;
    this.P100Lang       = gn_Lang;
    this.P100DBContext  = 0;            // Options for DB Context: 0->Workspace, 1->Current version, 2->Change list
    this.P100ChListNum  = -1;
    //Page #12 - Versions to compare
    this.P12Workspace   = false;        // Flag for reference model to workspace model comparision
    this.P12CurrVersion = false;        // Flag for reference model to current version model comparision
    this.P12ChangeList  = false;        // Flag for reference model to change list version model(s) comparision
    this.P12ChListVers  = [];           // Array of selected version numbers for reference model to change list version model(s) comparision {1,2,3,4,5,..}
    //Page #14 - anykind temporary array used to echange and store models found and selected by user choosen attribute
    this.aTempArray    = null;
    //Page #30 - Comparison options
    this.oCmpOptions    = new __cmp_ComparisonOptions();
    // General class variables
    this.aFilters       = sortAndFilterFilters( ArisData.getConfigurationFilters( gn_Lang ) );
    this.aDBLangs       = null;
    this.aChListInfos   = null;
    this.aDBNames       = _sortStrArray( ArisData.GetDatabaseNames( ), java.lang.String(ArisData.getActiveDatabase().Name( gn_Lang, true)) );
    this.aAttributes    = _sortAttrByNames( ArisData.ActiveFilter().AttrTypes( Constants.CID_MODEL ) );
    this.aModVersions   = null;
    this.oMasterVariant = new cl_MasterVariant();

    cl_UISettings.prototype.getRefModelVersions = function( ){
        if( this.RefModel != null ){
            this.aModVersions   = getModelVersions( this.RefModel );// Ref. model versionable check
            this.RefVersioned   = ((this.aModVersions != null) && (this.aModVersions.length > 0))?true:false;
        }
    }

    cl_UISettings.prototype.getRefModelMastersVariants  = function( ){
        var oDB = (this.P11DBCompare == 0)?ArisData.getActiveDatabase():this.CompDB;
        if( (oDB != null) && (oDB.IsValid()) ){
            this.oMasterVariant.Initialize( this.RefModel, oDB, this.P11DBCompare );// Get Masters and Variants of selected model
        }
    }


    if( (selectedModels != null) && (selectedModels.length == 1) ){
        this.getRefModelVersions( );
        this.getRefModelMastersVariants( );
    }

    function sortAndFilterFilters( p_Array ){
        var aOut    = new Array();
        if( p_Array != null ){
            for( var i=0; i<p_Array.length; i++ ){
                if( !(p_Array[i].isEvaluationFilter()) ){
                    aOut.push( p_Array[i] );
                }
            }
            aOut.sort( sortFilterNames );
        }
        return aOut;
    }
    
    function _sortStrArray( p_Array, sException ){
        if( p_Array != null ){
            var aOut    = new Array();
            p_Array.sort( sortStrings );
            if( (sException != null) && (sException.length() > 0)  ){
                for( var i=0; i<p_Array.length; i++ ){
                    if( sException.compareToIgnoreCase( java.lang.String(p_Array[i]) ) != 0 ){
                        aOut.push( p_Array[i] );
                    }
                }//END::for_i
            }
            return aOut;
        }
        return p_Array;
    }
    
    function _sortAttrByNames( p_Attr ){
        if( p_Attr != null ){
            p_Attr.sort( sortAttrNames );
        }
        return p_Attr;
    }

    cl_UISettings.prototype.DBNames     = function( ){
            return this.aDBNames;
    }

    cl_UISettings.prototype.DBName      = function( p_Idx ){
        if( (this.aDBNames != null) && (this.aDBNames.length > 0) && ((p_Idx < this.aDBNames.length) && (p_Idx >= 0))){
            return java.lang.String( this.aDBNames[ p_Idx ] );
        }
        return null;
    }
    
    cl_UISettings.prototype.getDBNameIdx    = function( p_sName ){
        if( (p_sName != null) && (p_sName.length() > 0) && (this.aDBNames != null) && (this.aDBNames.length > 0) ){
            for( var i=0; i < this.aDBNames.length; i++ ){
                var sTmp    = this.DBName( i );
                if( (sTmp != null) && (sTmp.compareToIgnoreCase( p_sName ) == 0) ){
                    return i;
                }
            }//END::for_i
        }
        return 0;
    }

    cl_UISettings.prototype.Attributes      = function( ){
            return this.aAttributes;
    }

    cl_UISettings.prototype.setAttributes   = function( p_nNum ){
        this.aAttributes    = _sortAttrByNames( ArisData.ActiveFilter().AttrTypes( p_nNum ) );
    }
    
    cl_UISettings.prototype.getAttributes   = function( p_Idx ){
        if( (this.aAttributes != null) && (this.aAttributes.length > 0) && ((p_Idx < this.aAttributes.length) && (p_Idx >= 0))){
            return this.aAttributes[ p_Idx ];
        }
        return null;
    }

    cl_UISettings.prototype.AttrNames    = function( ){
        var aOut    = new Array();
        if( (this.aAttributes != null) && (this.aAttributes.length > 0) ){
            for(var i=0; i<this.aAttributes.length; i++ ){
                aOut.push( getAttributeName( this.aAttributes[i] ));
            }//END::for_i
        }
        return aOut;
        
        function getAttributeName(p_attrTypeNum) {
            var sName = ArisData.ActiveFilter().AttrTypeName(p_attrTypeNum) + " [" + 
                        ArisData.ActiveFilter().getAPIName(Constants.CID_ATTRDEF, p_attrTypeNum) + "]";
            return java.lang.String( sName );
        }
    }
    
    cl_UISettings.prototype.getAttrIdx  = function( p_nNum ){
        if( (p_nNum != null) && (p_nNum > 0) && (this.aAttributes != null) && (this.aAttributes.length > 0) ){
            for( var i=0; i<this.aAttributes.length; i++ ){
                if( this.getAttributes( i ) == p_nNum ){
                    return i;
                }
            }//END::for_i
        }
        return 0;
    }
    
    cl_UISettings.prototype.FilterNames    = function( ){
        var aOut    = new Array();
        if( (this.aFilters != null) && (this.aFilters.length > 0) ){
            for(var i=0; i<this.aFilters.length; i++ ){
                aOut.push( java.lang.String( this.aFilters[i].getName() ) );
            }//END::for_i
        }
        return aOut;
    }
    cl_UISettings.prototype.getFilterNameIdx    = function( p_sName ){
        if( (p_sName != null) && (p_sName.length() > 0) && (this.aFilters != null) && (this.aFilters.length > 0) ){
            for(var i=0; i<this.aFilters.length; i++ ){
                var sTmp    = java.lang.String( this.aFilters[i].getName() );
                if( (sTmp != null) && (sTmp.compareToIgnoreCase( p_sName ) == 0) ){
                    return i;
                }
            }//END::for_i
        }
        return 0;
    }
    cl_UISettings.prototype.getConfigFilter = function( p_sGUID ){
        if( (p_sGUID != null) && (gs_Empty.compareToIgnoreCase( p_sGUID ) != 0) ){
            if( (this.aFilters != null) && (this.aFilters.length > 0) ){
                for(var i=0; i<this.aFilters.length; i++ ){
                    var a_sFilter   = java.lang.String( this.aFilters[i].getGUID() );
                    var p_sFilter   = java.lang.String( this.p_sGUID );
                    if( a_sFilter.compareToIgnoreCase( p_sFilter ) == 0 ){
                        return this.aFilters[i];
                    }
                }//END::for_i
            }
        }
        
        return null;
    }

    cl_UISettings.prototype.LangNames    = function( ){
        var aOut    = new Array();
        if( (this.aDBLangs != null) && (this.aDBLangs.length > 0) ){
            for(var i=0; i<this.aDBLangs.length; i++ ){
                aOut.push( java.lang.String( this.aDBLangs[i].Name( gn_Lang ) ) );
            }//END::for_i
        }
        return aOut;
    }
    cl_UISettings.prototype.getLangNamesIdx = function( p_Lang ){
        var aOut    = new Array();
        if( (this.aDBLangs != null) && (this.aDBLangs.length > 0) ){
            for(var i=0; i<this.aDBLangs.length; i++ ){
                if( this.aDBLangs[i].LocaleId() == p_Lang ){
                    return i;
                }
            }//END::for_i
        }
        return 0;
    }

    cl_UISettings.prototype.ChListInfos  = function( ){
        var aOut    = new Array();
        if( (this.aChListInfos != null) && (this.aChListInfos.length > 0) ){
            for(var i=0; i<this.aChListInfos.length; i++ ){
                aOut.push( java.lang.String( this.aChListInfos[i].getID() ).concat(" -  ").concat( this.aChListInfos[i].getDescription()) );
            }//END::for_i
        }
        return aOut;
    }
    
    cl_UISettings.prototype.ChListInfo  = function( p_Idx ){
        if( (p_Idx != null) && (p_Idx > 0) && (this.aChListInfos != null) && (p_Idx < this.aChListInfos.length) ){
            return this.aChListInfos[ p_Idx ];
        }
        return null;
    }
    
    cl_UISettings.prototype.getModelsByAttr = function( ){
        var aOut    = new Array();
        var oDB     = (this.P11DBCompare == 1)?this.CompDB:ArisData.getActiveDatabase();
        if( (oDB != null) && (this.RefModel != null) ){
            var aAttr           = getAttrValue( this.RefModel, this.P11AttrNumber, this.P100Lang );
            if( aAttr != null ){
                var sRefAttrValue   = (aAttr["VALUE"] == null)?gs_Empty:aAttr["VALUE"];
                var nCompareFlags   = (this.P11MatchCase)?(Constants.SEARCH_CMP_EQUAL|Constants.SEARCH_CMP_CASESENSITIVE):Constants.SEARCH_CMP_EQUAL;
                var aModels         = oDB.Find( Constants.SEARCH_MODEL, this.P11AttrNumber, this.P100Lang, sRefAttrValue, nCompareFlags );
                
                if( aModels != null ){
                    for( var i=0; i<aModels.length; i++ ){
                        if( aModels[i] != null && aModels[i].IsValid() && (!aModels[i].IsEqual(this.RefModel)) ){
                            aOut.push( aModels[i] );
                        }
                    }//END::for_i
                }
            }
        }
        return aOut;
    }
    
    cl_UISettings.prototype.getModelsByGUID = function( ){
        var aOut    = new Array();
        if( (this.RefModel != null) && (this.CompDB != null) ){
            var sRefModelGUID   = this.RefModel.GUID();
            var oModel          = this.CompDB.FindGUID( sRefModelGUID, Constants.CID_MODEL );

            if( oModel != null && oModel.IsValid() ){
                aOut.push( oModel );
            }
        }
        return aOut;
    }

    cl_UISettings.prototype.getStartingModelsNames  = function( ){
        var aOut    = new Array();
        if( (this.aModels != null) && (this.aModels.length > 0) ){
            for(var i=0; i<this.aModels.length; i++ ){
                aOut.push( java.lang.String( getModelName(this.aModels[i], gn_Lang) ) );
            }//END::for_i
        }
        return aOut;
    }
    cl_UISettings.prototype.getStartingModelsIdx    = function( p_sName ){
        if( (p_sName != null) && (p_sName.length() > 0) && (this.aModels != null) && (this.aModels.length > 0) ){
            for(var i=0; i<this.aModels.length; i++ ){
                var sTmp    = java.lang.String( getModelName(this.aModels[i], gn_Lang) );
                if( (sTmp != null) && (sTmp.compareToIgnoreCase( p_sName ) == 0) ){
                    return i;
                }
            }//END::for_i
        }
        return 0;
    }
    cl_UISettings.prototype.getStartingModelByIdx       = function( p_Idx ){
        if( (p_Idx != null) && (p_Idx >= 0) && (p_Idx < this.aModels.length) && (this.aModels != null) ){
            return this.aModels[ p_Idx ];
        }
        return null;
    }
    cl_UISettings.prototype.filterStartingModelsByIdx   = function( p_Idx ){
        var aOut    = new Array();
        if( (p_Idx != null) && (p_Idx >= 0) && (p_Idx < this.aModels.length) && (this.aModels != null) ){
            for( var i=0; i<this.aModels.length; i++ ){
                if( i != p_Idx ) aOut.push( this.aModels[i] );
            }//END::for_i
        }
        return aOut;
    }
        
    // Stores settings via properties from Designer into oUsrSettings
    cl_UISettings.prototype.getSettingsFromDesigner = function( ){
        this.oCmpOptions.CmpExistFirstMod = getBoolPropertyValue("itemExistingOnlyInFirstModel");
        this.oCmpOptions.CmpExistSecondMod = getBoolPropertyValue("itemExistingOnlyInSecondModel");
        this.oCmpOptions.CmpChangeBothMod = getBoolPropertyValue("modifiedItemsExistingInBothModel");

        this.oCmpOptions.ItmModProperties = getBoolPropertyValue("modelProperties");
        
        this.oCmpOptions.ItmObjDefinitions.Checked = getBoolPropertyValue("objectDefinition");
        this.oCmpOptions.ItmObjDefinitions.Attributes = getBoolPropertyValue("objectAttributes");
        this.oCmpOptions.ItmObjDefinitions.SystemAttributes = getBoolPropertyValue("objectSystemAttributes");
        this.oCmpOptions.ItmObjDefinitions.Occurrences.Checked = getBoolPropertyValue("objectOccurrences");
        this.oCmpOptions.ItmObjDefinitions.Occurrences.Appearance = getBoolPropertyValue("objectAppearence");
        this.oCmpOptions.ItmObjDefinitions.Occurrences.Position = getBoolPropertyValue("objectPositionSize");
        this.oCmpOptions.ItmObjDefinitions.Occurrences.AttrPlace = getBoolPropertyValue("objectAttributePlacements");
        
        this.oCmpOptions.ItmCxnDefinitions.Checked = getBoolPropertyValue("connectionDefinition");
        this.oCmpOptions.ItmCxnDefinitions.Attributes = getBoolPropertyValue("connectionAttributes");
        this.oCmpOptions.ItmCxnDefinitions.Occurrences.Checked = getBoolPropertyValue("connectionOccurrences");
        this.oCmpOptions.ItmCxnDefinitions.Occurrences.Appearance = getBoolPropertyValue("connectionAppearences");
        this.oCmpOptions.ItmCxnDefinitions.Occurrences.Position = getBoolPropertyValue("connectionPoints");
        this.oCmpOptions.ItmCxnDefinitions.Occurrences.AttrPlace = getBoolPropertyValue("connectionAttributePlacements");
        
        this.oCmpOptions.ItmGraphicObjects = getBoolPropertyValue("gfxObjects");
        this.oCmpOptions.ItmOLEObjects = getBoolPropertyValue("oleObjects");
        this.oCmpOptions.ItmFreeText = getBoolPropertyValue("freeformtTexts");
        
        /*var sAttrIdentify = getAttrPropertyValue("setAttributeIdentify");
        this.oCmpOptions.AddIdenticalAttr = (parseInt(sAttrIdentify) > 0);
        if( this.oCmpOptions.AddIdenticalAttr ){
            this.oCmpOptions.AddAttrNumber = sAttrIdentify;
            this.oCmpOptions.AddMatchCase = getBoolPropertyValue("setCaseSensitive");
            this.oCmpOptions.AddLineBreaksSpaces = getBoolPropertyValue("setIncludeLineBreaks");
        }*/
        this.oCmpOptions.MasterVariantComp = false;

        function getAttrPropertyValue(p_sPropKey) {
            var property = Context.getProperty(p_sPropKey);
            if (property != null) {
                return property;
            }
            return "-1";
        }
        
        function getBoolPropertyValue(p_sPropKey) {
            var property = Context.getProperty(p_sPropKey);
            if (property != null) {
                return (StrComp(property, "true") == 0);
            }
            return false;
        }
    }
}//END::cl_UISettings()
// END::Classes------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------

// Output part-------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
function defineStyles( p_Output ){
    // DO NOT TRANSLATE THESE STRINGS - MUST BE EXACTLY LIKE IT IS!!!
    p_Output.DefineF("TEXT_SUMM_HEADER", getString("TEXT_FONT_DEFAULT"), 11, CC_WHITE, CC_DARK_GREEN,  Constants.FMT_BOLD | Constants.FMT_LEFT | Constants.FMT_VBOTTOM | Constants.FMT_EXCELMODIFY, 1, 1, 0, 0, 2, 1);
    p_Output.DefineF("TEXT_STYLE_BOLD", getString("TEXT_FONT_DEFAULT"), 10, CC_BLACK, CC_WHITE,  Constants.FMT_BOLD | Constants.FMT_LEFT | Constants.FMT_VBOTTOM | Constants.FMT_EXCELMODIFY, 1, 1, 0, 0, 2, 1);
    p_Output.DefineF("TEXT_STYLE_DEFAULT", getString("TEXT_FONT_DEFAULT"), 10, CC_BLACK, CC_WHITE,  Constants.FMT_LEFT | Constants.FMT_VBOTTOM | Constants.FMT_EXCELMODIFY, 1, 1, 0, 0, 2, 1);
    p_Output.DefineF("TEXT_STYLE_BLUE", getString("TEXT_FONT_DEFAULT"), 10, CC_BLUE, CC_WHITE,  Constants.FMT_LEFT | Constants.FMT_VBOTTOM | Constants.FMT_EXCELMODIFY, 1, 1, 0, 0, 2, 1);
    p_Output.DefineF("TEXT_STYLE_RED", getString("TEXT_FONT_DEFAULT"), 10, CC_RED, CC_WHITE,  Constants.FMT_LEFT | Constants.FMT_VBOTTOM | Constants.FMT_EXCELMODIFY, 1, 1, 0, 0, 2, 1);
    p_Output.DefineF("TEXT_STYLE_TRANSPARENT", getString("TEXT_FONT_DEFAULT"), 10, CC_TRANSPARENT, CC_TRANSPARENT,  Constants.FMT_LEFT | Constants.FMT_VBOTTOM | Constants.FMT_EXCELMODIFY, 1, 1, 0, 0, 2, 1);
    
    p_Output.DefineF("TEXT_CODE_GREEN", getString("TEXT_FONT_DEFAULT"), 10, CC_BLACK, CC_GREEN,  Constants.FMT_LEFT | Constants.FMT_VBOTTOM | Constants.FMT_EXCELMODIFY, 1, 1, 0, 0, 2, 1);
    p_Output.DefineF("TEXT_CODE_RED", getString("TEXT_FONT_DEFAULT"), 10, CC_BLACK, CC_RED,  Constants.FMT_LEFT | Constants.FMT_VBOTTOM | Constants.FMT_EXCELMODIFY, 1, 1, 0, 0, 2, 1);
    p_Output.DefineF("TEXT_CODE_YELLOW", getString("TEXT_FONT_DEFAULT"), 10, CC_BLACK, CC_YELLOW,  Constants.FMT_LEFT | Constants.FMT_VBOTTOM | Constants.FMT_EXCELMODIFY, 1, 1, 0, 0, 2, 1);
    // DO NOT TRANSLATE THESE STRINGS - MUST BE EXACTLY LIKE IT IS!!!
}//END::defineStyles()

function setNewFrameStyle( p_Output, p_Style ){
    // Usage: Frames{0|1} [Bottom, Left, Right, Top]; p_Style example: [1,1,1,1]
    p_Output.ResetFrameStyle( );
    p_Output.SetFrameStyle( Constants.FRAME_BOTTOM,    p_Style[0] );
    p_Output.SetFrameStyle( Constants.FRAME_LEFT,      p_Style[1] );
    p_Output.SetFrameStyle( Constants.FRAME_RIGHT,     p_Style[2] );
    p_Output.SetFrameStyle( Constants.FRAME_TOP,       p_Style[3] );
}//END::setNewFrameStyle()

function addCell( p_Output, p_fStyle, p_Text, p_PerCnt, p_txtStyle ){
    // Usage example: addCell( p_Output, [0,1,1,0], "text", 1, 1, 25, getString("TEXT_STYLE_DEFAULT") );
    if( p_fStyle.length > 0 ){
        setNewFrameStyle( p_Output, p_fStyle );
    }
    p_Output.TableCellF( p_Text, p_PerCnt, p_txtStyle );
}//END::addCell()

function addGraphic( p_Output, p_fStyle, p_Text, p_Picture, p_PerCnt, p_txtStyle ){
    var aPicSize    = resizePicture( p_Output, p_Picture, [200,200]);

    addCell( p_Output, p_fStyle, p_Text, p_PerCnt, p_txtStyle );
    p_Output.OutGraphic( p_Picture, -1, aPicSize["WIDTH"], aPicSize["HEIGHT"] );
}//END::addGraphic()

function addEmptyTableRow( p_Output, p_Num ){
    var aStyle  = [0,0,0,0];
    if( (p_Output == null) || (p_Num == null) ) return;
    p_Num   = (p_Num < 1)? 1: p_Num;
    
    for(var i=0; i<p_Num; i++){
        p_Output.TableRow();
        addCell( p_Output, aStyle, "", 35, "TEXT_STYLE_TRANSPARENT" );
        addCell( p_Output, aStyle, "", 20, "TEXT_STYLE_TRANSPARENT" );
        addCell( p_Output, aStyle, "", 20, "TEXT_STYLE_TRANSPARENT" );
        addCell( p_Output, aStyle, "", 25, "TEXT_STYLE_TRANSPARENT" );
    }
}//END::addEmptyTableRow()

function createSummaryStatistics( p_Output, oComparisionSet ){
    p_Output.BeginTable( 100, CC_BLACK, CC_WHITE, Constants.FMT_VCENTER | Constants.FMT_REPEAT_HEADER, 0 );
    
    // Output Header with: Name, DB, Server, Path
    p_Output.TableRow( );
        addCell( p_Output, [1,1,1,1], getString("TEXT_NAME_TAB"), 35, "TEXT_SUMM_HEADER" );
        addCell( p_Output, [1,1,1,1], getString("TEXT_DB"), 20, "TEXT_SUMM_HEADER" );
        addCell( p_Output, [1,1,1,1], getString("TEXT_SERVER"), 20, "TEXT_SUMM_HEADER" );
        addCell( p_Output, [1,1,1,1], getString("TEXT_PATH"), 25, "TEXT_SUMM_HEADER" );
    var aModels = oComparisionSet.aModels;
    for( var i=0; i<aModels.length; i++ ){// Output Models list...
        var nStyle  = (i==0)?"TEXT_STYLE_BOLD":"TEXT_STYLE_DEFAULT";
        p_Output.TableRow( );
        if (aModels[i] != null){
            addCell( p_Output, [1,1,1,1], getModelName(aModels[i], gn_Lang), 35, nStyle );
            addCell( p_Output, [1,1,1,1], _getModelDB( i, oComparisionSet ).Name( gn_Lang ), 20, nStyle );
            addCell( p_Output, [1,1,1,1], _getModelDB( i, oComparisionSet ).ServerName(), 20, nStyle );
            addCell( p_Output, [1,1,1,1], aModels[i].Group( ).Path( gn_Lang ), 25, nStyle );
        }
    }//END::for_i
    
    addEmptyTableRow( p_Output, 2 );
    
    // Output Statistics Header... Comparison settings, Settings, Results
    p_Output.TableRow( );
        addCell( p_Output, [1,1,1,1], getString("TEXT_COMP_SETTINGS"), 35, "TEXT_SUMM_HEADER" );
        addCell( p_Output, [1,1,1,1], getString("TEXT_SETTINGS"), 20, "TEXT_SUMM_HEADER" );
        addCell( p_Output, [1,1,1,1], getString("TEXT_RESULTS"), 20, "TEXT_SUMM_HEADER" );
        addCell( p_Output, [0,0,0,0], "", 25, "TEXT_STYLE_TRANSPARENT" );
    // Output Statistics...
    oComparisionSet.outputStatistics( p_Output, "Criterion", getString("TEXT_MODCOMP_CRITERION") );
    oComparisionSet.outputStatistics( p_Output, "AddIdenticalAttr", getString("TEXT_MATCHING_OBJECTS") );

    oComparisionSet.outputStatistics( p_Output, "CmpExistFirstMod", getString("TEXT_ITEM_EXIST_REF_MOD") );
    oComparisionSet.outputStatistics( p_Output, "CmpExistSecondMod", getString("TEXT_ITEM_EXIST_COMP_MOD") );
    oComparisionSet.outputStatistics( p_Output, "CmpChangeBothMod", getString("TEXT_ITEM_ALL_MODELS") );
    oComparisionSet.outputStatistics( p_Output, "ItmModProperties", getString("TEXT_MODEL_PROPERTIES") );

    oComparisionSet.outputStatistics( p_Output, "ItmObjDefinitions", getString("TEXT_OBJECT_DEF") );
        oComparisionSet.outputStatistics( p_Output, "ItmObjAttributes", getString("TEXT_OBJECT_ATTRS") );
        oComparisionSet.outputStatistics( p_Output, "ItmObjOccurrences", getString("TEXT_OBJ_OCCU") );
        oComparisionSet.outputStatistics( p_Output, "ItmObjAppearance", getString("TEXT_APPEAR_SYMBOL") );
        oComparisionSet.outputStatistics( p_Output, "ItmObjPosition", getString("TEXT_POSITION_SIZE") );
        oComparisionSet.outputStatistics( p_Output, "ItmObjAttrPlace", getString("TEXT_ATTR_PLACEMENT") );
    oComparisionSet.outputStatistics( p_Output, "ItmCxnDefinitions", getString("TEXT_CONNECTION_DEFS") );
        oComparisionSet.outputStatistics( p_Output, "ItmCxnAttributes", getString("TEXT_CONNECTION_ATTRS") );
        oComparisionSet.outputStatistics( p_Output, "ItmCxnOccurrences", getString("TEXT_CONNECTION_OCCUS") );
        oComparisionSet.outputStatistics( p_Output, "ItmCxnAppearance", getString("TEXT_CONNECTION_APPEAR") );
        oComparisionSet.outputStatistics( p_Output, "ItmCxnPosition", getString("TEXT_CONNECTION_POINTS") );
        oComparisionSet.outputStatistics( p_Output, "ItmCxnAttrPlace", getString("TEXT_ATTR_PLACEMENTS") );

    oComparisionSet.outputStatistics( p_Output, "ItmGraphicObjects", getString("TEXT_GRAPHIC_OBJ") );
    oComparisionSet.outputStatistics( p_Output, "ItmOLEObjects", getString("TEXT_OLE_OBJ") );
    oComparisionSet.outputStatistics( p_Output, "ItmFreeText", getString("TEXT_FREE_TEXT") );
        
    p_Output.EndTable( getString("TABNAME_SUMMARY"), 100, getString("TEXT_FONT_DEFAULT"), 8, CC_TRANSPARENT, CC_TRANSPARENT, Constants.FILLTYPE_SOLID, Constants.FMT_LEFT, 0);
    
    function _getModelDB( Flag, oComparisionSet ){
        if( (Flag != null) && (Flag != 0) ){
            if( oComparisionSet.nDBCompare == 1 ){
                return oComparisionSet.oCompDB;
            }
        }
        return oComparisionSet.oActDB;
    }//END::_getModelDB()
}//END::createSummaryStatistics()


function createDetailedOutput( p_Output, oComparisionSet, aComparisonTable ){
    p_Output.BeginTable( 100, CC_BLACK, CC_WHITE, Constants.FMT_VCENTER | Constants.FMT_REPEAT_HEADER, 0 );
    
    // Output Header with: Element, Type, Difference, Difference Details, Model Names
    p_Output.TableRow( );
        addCell( p_Output, [1,1,1,1], getString("TEXT_ELEMENT"), 15, "TEXT_SUMM_HEADER" );
        addCell( p_Output, [1,1,1,1], getString("TEXT_TYPE_TAB"), 15, "TEXT_SUMM_HEADER" );
        addCell( p_Output, [1,1,1,1], getString("TEXT_DIFFERENCE"), 15, "TEXT_SUMM_HEADER" );
        addCell( p_Output, [1,1,1,1], getString("TEXT_DIFF_DETAILS"), 25, "TEXT_SUMM_HEADER" );
        addCell( p_Output, [1,1,1,1], getModelName(oComparisionSet.oRefModel, gn_Lang), 15, "TEXT_SUMM_HEADER" );
    for( var i=0; i<gn_ModelCount; i++ ){
        addCell( p_Output, [1,1,1,1], getModelName(oComparisionSet.aCompModels[i], gn_Lang), 15, "TEXT_SUMM_HEADER" );
    }
    // Output data rows as Element, Type, Difference, Difference Details
    for( var iRow=0; iRow<aComparisonTable.length; iRow++ ){
        var rowObject   = aComparisonTable[iRow];
        var aElements   = rowObject.aElements;
        p_Output.TableRow( );
            addCell( p_Output, [1,1,1,1], rowObject.sName, 15, "TEXT_STYLE_DEFAULT" );
            addCell( p_Output, [1,1,1,1], rowObject.nType, 15, "TEXT_STYLE_DEFAULT" );// ArisData.ActiveFilter().ObjTypeName( rowObject.oRefObj.TypeNum() )
            addCell( p_Output, [1,1,1,1], ((rowObject.nDiffType == Constants.MODCOMP_DIFF_BOTH)?getString("TEXT_DIFFERENCE"):getString("TEXT_EXISTENCE")), 15, "TEXT_STYLE_DEFAULT" );
            addCell( p_Output, [1,1,1,1], rowObject.sDiffDetails, 25, "TEXT_STYLE_DEFAULT" );
        // Output column information - each column is one comparison model
        for( var iCol=0; iCol<(gn_ModelCount+1); iCol++ ){
            var colObject   = aElements[iCol];
            var colValue = (colObject != null) ? _getColumnValue( colObject ) : _getColumnValue( aElements[0] ); // 'colObject == null' means no difference -> current value = value of reference (= aElements[0])
            addCell( p_Output, [1,1,1,1], cutMaxLength( colValue ), 15, _getColumnStyle( colObject ) );
        }//END::for_iCol
    }//END::for_iRow
    //addCell( p_Output, [1,1,1,1], commonUtils.attsall.formatString( "Comparison model @0", [i+1]), 15, "TEXT_SUMM_HEADER" );

    p_Output.EndTable( getString("TABNAME_COMP_DETAILS"), 100, getString("TEXT_FONT_DEFAULT"), 8, CC_TRANSPARENT, CC_TRANSPARENT, Constants.FILLTYPE_SOLID, Constants.FMT_LEFT, 0);
    
    function _getColumnValue( oElement ){
        if( oElement == null ){
            return getString("TEXT_DOES_NOT_EXIST");
        }
        if( oElement.nDiffType == Constants.MODCOMP_DIFF_BOTH && oElement.bSubChange ){
            if( oElement.oSubObj == null ){
                return getString("TEXT_NOT_MAINTAINED");
            } else {
                return getString("TEXT_MANTAINED");
            }
        }
        return oElement.sValue;
    }
    
    function _getColumnStyle( oElement ){
        if( oElement == null ){
//            return "TEXT_STYLE_RED";
            return "TEXT_STYLE_DEFAULT";
        }
        if( oElement.nDiffType == Constants.MODCOMP_DIFF_BOTH && oElement.bSubChange ){
            return "TEXT_STYLE_DEFAULT";
        }
        if( oElement.nDiffType == Constants.MODCOMP_DIFF_LEFTONLY || oElement.nDiffType == Constants.MODCOMP_DIFF_RIGHTONLY ){
            if( oElement.oObj == null ){
                return "TEXT_STYLE_RED";
            } else {
                return "TEXT_STYLE_BLUE";
            }
        }
        return "TEXT_STYLE_DEFAULT";
    }
}//END::createDetailedOutput()


function createComparisonStatements( p_Output ){
    p_Output.BeginTable( 100, CC_BLACK, CC_WHITE, Constants.FMT_VCENTER | Constants.FMT_REPEAT_HEADER, 0 );
    
    // Output Header with: Summary, Code in green
    p_Output.TableRow( );
        addCell( p_Output, [1,1,1,1], getString("TABNAME_SUMMARY"), 70, "TEXT_SUMM_HEADER" );
        addCell( p_Output, [1,1,1,1], getString("TEXT_CODE"), 30, "TEXT_SUMM_HEADER" );

    for (var i=0; i<ga_Summary.length; i++ ){
        p_Output.TableRow( );
            addCell( p_Output, [1,1,1,1], cutMaxLength( ga_Summary[i].stext ), 70, "TEXT_STYLE_DEFAULT" );
            addCell( p_Output, [1,1,1,1], ga_Summary[i].saction, 30, _getCodeCellStyle( ga_Summary[i].saction ) );
    }//END::for_i
    
    p_Output.EndTable( getString("TABNAME_COMP_STATEMENTS"), 100, getString("TEXT_FONT_DEFAULT"), 8, CC_TRANSPARENT, CC_TRANSPARENT, Constants.FILLTYPE_SOLID, Constants.FMT_LEFT, 0);
    
    function _getCodeCellStyle( saction ) {
        if (StrComp(saction, gs_Updated) ==  0) return "TEXT_CODE_YELLOW";
        if (StrComp(saction, gs_Created) ==  0) return "TEXT_CODE_GREEN"; 
        if (StrComp(saction, gs_Deleted) ==  0) return "TEXT_CODE_RED"; 
        return "TEXT_STYLE_DEFAULT";
    }//END::_getCodeCellStyle()
}//END::createComparisonStatements()

function createGraphicOutputPreparation( p_Output, oComparisionSet ){
    p_Output.BeginTable( 200, CC_BLACK, CC_WHITE, Constants.FMT_VCENTER | Constants.FMT_REPEAT_HEADER, 0 );
    
    // Output Header with models name
    var aModels = oComparisionSet.aModels;
    p_Output.TableRow( );
    for( var i=0; i<aModels.length; i++ ){
        addCell( p_Output, [1,1,1,1], getModelName(aModels[i], gn_Lang), 200/aModels.length, "TEXT_SUMM_HEADER" );
    }

    //name to be recognized by createGraphicOutputUsingExcel()
    p_Output.EndTable( getString("TABNAME_GRAPHICS"), 100, getString("TEXT_FONT_DEFAULT"), 8, CC_TRANSPARENT, CC_TRANSPARENT, Constants.FILLTYPE_SOLID, Constants.FMT_LEFT, 0);
}//END::createGraphicOutputPreparation()

function createGraphicOutputUsingExcel(p_Output, p_sFileName, oComparisonSet ){
    
    var XlsWorkbook = Context.createExcelWorkbook(p_sFileName, p_sFileName)
    var XlsSheet = null
    var aSheets = XlsWorkbook.getSheets()//.getName()
    for(var i=0; i<aSheets.length; i++)
    {
        if((""+aSheets[i].getName()) == getString("TABNAME_GRAPHICS") )
        {
            XlsSheet = aSheets[i]
            break;
        }
    }
    
    if(XlsSheet!=null)
    {
        var POINT_DPI = 72;
        var PIXEL_DPI = 96;        
        var initialRow = 1;
        //var maxRowHeight = 65535/20;//because height is short and set in twips
        for (var i=0; i<ga_ModelGraphic.length; i++ ){
            
            var xlFontForCalculation = XlsWorkbook.getFontAt(XlsSheet.cell(initialRow, i).getCellStyle().getFontIndex())
            var javaFontForCalculation = new java.awt.Font(xlFontForCalculation.getFontName(),0,xlFontForCalculation.getFontHeightInPoints())
            var rectangle = javaFontForCalculation.getMaxCharBounds(new java.awt.font.FontRenderContext(javaFontForCalculation.getTransform(),true,true))
            
            ga_ModelGraphic[i].setZoom(100)
            var cellWidthPixels = (XlsSheet.getColumnWidth(i)/256.0)*(rectangle.getWidth()/4) * (PIXEL_DPI/POINT_DPI) //* POINT_DPI/PIXEL_DPI
            var nPicWidth   = ga_ModelGraphic[i].getWidth(Constants.SIZE_PIXEL);
            var zoom = cellWidthPixels / nPicWidth
            if(zoom>1)
                zoom = 1;
            
            var nPicHeight   = zoom * ga_ModelGraphic[i].getHeight(Constants.SIZE_PIXEL) * POINT_DPI/PIXEL_DPI;//in point
            
            var rowsNeeded = Math.ceil(nPicHeight / (XlsSheet.getDefaultRowHeight()/20));//int
            for(var nRow = 1; nRow<rowsNeeded; nRow++)
                XlsSheet.cell(initialRow+nRow, i) //ensure cells exist 
            var restInLastRow = rowsNeeded*XlsSheet.getDefaultRowHeight()/20 - nPicHeight
            
            //get image data
            ga_ModelGraphic[i].setZoom(100)
            ga_ModelGraphic[i].Save(p_Output, "model.png")
            var imageData = Context.getFile("model.png", Constants.LOCATION_OUTPUT)
            Context.deleteFile("model.png")
            
            XlsSheet.setPicture(imageData, Constants.XL_PICTURE_TYPE_PNG, i, initialRow, i, initialRow+rowsNeeded-1, 0,0,nPicWidth*zoom*1.98, Math.abs(restInLastRow)*20)
        }//END::for_i        
    }

    XlsWorkbook.write()
}//END::createGraphicOutputUsingExcel()

function cutMaxLength(sValue) { // AGG-11826 The maximum length of cell contents (text) is 32,767 characters 
    const MAX_LENGTH = 32767;
    var sNewValue = "" + sValue;
    if (sNewValue.length > MAX_LENGTH) {
        return sNewValue.substr(0, MAX_LENGTH);
    }
    return sValue;
}

function RGB(r, g, b) {
    return (new java.awt.Color(r/255.0,g/255.0,b/255.0,1)).getRGB() & 0xFFFFFF;
}//END::RGB()

// END::Output-------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------

function getModelTypesIncludingUserDefined_Array(p_aOrgModelTypeNums) {
    var aModelTypes = new Array();
    
    for (var i = 0; i < p_aOrgModelTypeNums.length; i++) { 
        aModelTypes = aModelTypes.concat(getModelTypesIncludingUserDefined(p_aOrgModelTypeNums[i]));
    }    
    return aModelTypes;
}

function getModelName(oModel, nLocale) {
    if (oModel == null) return;
    // AGA-11063
    var sName = oModel.Name(nLocale, true);
    
    var nVersion = oModel.Database().getVersion();
    if (nVersion != -1) {
        sName += " [" + nVersion + "]";
    }
    return sName;
}

function doToLowerCase(str) {
    return (""+str).toLowerCase();
}

function doReplace(string, pattern, replacement) {
  if (pattern == "") {
      return string;
  }
  var result = "";
  var tail   = "" + string;

  for(;;) {
    var idx = tail.indexOf(pattern);
    if (idx == -1) break;

    var newTail = tail.substr(idx + pattern.length);
    var head = "";
    if(idx > 0) {
      head = tail.substr(0, idx);
    }
    result = result + head + replacement;
    tail = newTail;
  }
  return result + tail;
}

// for local test purposes 
/* function simulateAPGInput() {
    
    Context.setProperty("updateSystemAttributes","false");
    Context.setProperty("modelVersion","");
    
    Context.setProperty("connectionAppearences","true");
    Context.setProperty("connectionAttributePlacements","true");
    Context.setProperty("connectionDefinition","true");
    Context.setProperty("connectionOccurrences","true");
    Context.setProperty("connectionPoints","true");
    Context.setProperty("freeformtTexts","true");
    Context.setProperty("gfxObjects","true");
    Context.setProperty("itemExistingOnlyInFirstModel","true");
    Context.setProperty("itemExistingOnlyInSecondModel","true");
    Context.setProperty("modelProperties","true");
    Context.setProperty("modifiedItemsExistingInBothModel","true");
    Context.setProperty("objectAppearence","true");
    Context.setProperty("objectAttributePlacements","true");
    Context.setProperty("objectDefinition","true");
    Context.setProperty("objectOccurrences","true");
    Context.setProperty("objectPositionSize","true");
    Context.setProperty("oleObjects","true");
    
    Context.setProperty("connectionAttributes","true");
    Context.setProperty("objectAttributes","true");
    Context.setProperty("objectSystemAttributes","true");
}*/
